"use client"

import { useState, useEffect } from "react"
import { SplashScreen } from "@/components/splash-screen"
import { EnhancedMainApp } from "@/components/enhanced-main-app"
import { ThemeProvider } from "@/components/theme-provider"
import { LocationProvider } from "@/components/location-provider"
import { AIProvider } from "@/components/ai-provider"
import { LanguageProvider } from "@/components/language-provider"
import { LoginScreen } from "@/components/login-screen"

export default function BladiGoApp() {
  const [showSplash, setShowSplash] = useState(true)
  const [user, setUser] = useState(null)

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false)
    }, 4000)
    return () => clearTimeout(timer)
  }, [])

  // Show splash screen first
  if (showSplash) {
    return <SplashScreen />
  }

  // Then show login screen if user is not logged in
  if (!user) {
    return <LoginScreen onLogin={setUser} />
  }

  // Finally show the main enhanced app
  return (
    <LanguageProvider>
      <ThemeProvider>
        <LocationProvider>
          <AIProvider>
            <EnhancedMainApp />
          </AIProvider>
        </LocationProvider>
      </ThemeProvider>
    </LanguageProvider>
  )
}
