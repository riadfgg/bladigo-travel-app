"use client"

import { useState } from "react"
import { ArrowLeft, Mail, Phone, MapPin, Camera, Edit3, Star, Heart, Calendar } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface AccountScreenProps {
  onNavigate: (screen: string) => void
}

export function AccountScreen({ onNavigate }: AccountScreenProps) {
  const [user] = useState({
    name: "Ahmed Benali",
    email: "ahmed.benali@email.com",
    phone: "+213 555 123 456",
    location: "Algiers, Algeria",
    avatar: "/placeholder.svg?height=120&width=120",
    joinDate: "March 2024",
    tripsCompleted: 12,
    favoriteSpots: 28,
    reviews: 15,
  })

  const recentTrips = [
    {
      id: 1,
      destination: "Timgad Ruins",
      date: "Dec 2024",
      image: "/placeholder.svg?height=80&width=80",
      rating: 5,
    },
    {
      id: 2,
      destination: "Fort Santa Cruz",
      date: "Nov 2024",
      image: "/placeholder.svg?height=80&width=80",
      rating: 4,
    },
    {
      id: 3,
      destination: "Casbah of Algiers",
      date: "Oct 2024",
      image: "/placeholder.svg?height=80&width=80",
      rating: 5,
    },
  ]

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-indigo-100/80 via-purple-100/80 to-pink-100/80 dark:from-gray-900/80 dark:via-purple-900/80 dark:to-pink-900/80"></div>

      <div className="relative z-10 p-6 pb-24">
        {/* Header */}
        <div className="flex items-center justify-between mb-6 pt-12">
          <Button
            onClick={() => onNavigate("home")}
            className="bg-white/20 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
          >
            <ArrowLeft className="w-6 h-6 text-gray-700 dark:text-gray-200" />
          </Button>
          <h1 className="text-2xl font-bold text-gray-800 dark:text-white">My Account</h1>
          <Button className="bg-white/20 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3">
            <Edit3 className="w-6 h-6 text-gray-700 dark:text-gray-200" />
          </Button>
        </div>

        <div className="space-y-6">
          {/* Profile Card */}
          <Card className="bg-white/20 backdrop-blur-md border border-white/30 rounded-2xl p-6">
            <div className="flex items-center space-x-4 mb-6">
              <div className="relative">
                <img
                  src={user.avatar || "/placeholder.svg"}
                  alt={user.name}
                  className="w-20 h-20 rounded-full object-cover border-4 border-white/50"
                />
                <Button className="absolute -bottom-2 -right-2 bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 rounded-full p-2">
                  <Camera className="w-4 h-4 text-white" />
                </Button>
              </div>
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-1">{user.name}</h2>
                <p className="text-gray-600 dark:text-gray-300 mb-2">Traveler since {user.joinDate}</p>
                <div className="flex items-center space-x-1 text-amber-500">
                  <Star className="w-4 h-4 fill-current" />
                  <Star className="w-4 h-4 fill-current" />
                  <Star className="w-4 h-4 fill-current" />
                  <Star className="w-4 h-4 fill-current" />
                  <Star className="w-4 h-4 fill-current" />
                </div>
              </div>
            </div>

            {/* Contact Info */}
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-blue-600" />
                <span className="text-gray-700 dark:text-gray-200">{user.email}</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-green-600" />
                <span className="text-gray-700 dark:text-gray-200">{user.phone}</span>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin className="w-5 h-5 text-red-600" />
                <span className="text-gray-700 dark:text-gray-200">{user.location}</span>
              </div>
            </div>
          </Card>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4">
            <Card className="bg-white/20 backdrop-blur-md border border-white/30 rounded-2xl p-4 text-center">
              <div className="text-2xl font-bold text-blue-600 mb-1">{user.tripsCompleted}</div>
              <div className="text-sm text-gray-600 dark:text-gray-300">Trips</div>
            </Card>
            <Card className="bg-white/20 backdrop-blur-md border border-white/30 rounded-2xl p-4 text-center">
              <div className="text-2xl font-bold text-red-600 mb-1">{user.favoriteSpots}</div>
              <div className="text-sm text-gray-600 dark:text-gray-300">Favorites</div>
            </Card>
            <Card className="bg-white/20 backdrop-blur-md border border-white/30 rounded-2xl p-4 text-center">
              <div className="text-2xl font-bold text-amber-600 mb-1">{user.reviews}</div>
              <div className="text-sm text-gray-600 dark:text-gray-300">Reviews</div>
            </Card>
          </div>

          {/* Recent Trips */}
          <Card className="bg-white/20 backdrop-blur-md border border-white/30 rounded-2xl p-6">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">Recent Trips</h3>
            <div className="space-y-3">
              {recentTrips.map((trip) => (
                <div key={trip.id} className="flex items-center space-x-4 p-3 bg-white/10 rounded-xl">
                  <img
                    src={trip.image || "/placeholder.svg"}
                    alt={trip.destination}
                    className="w-12 h-12 rounded-lg object-cover"
                  />
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-800 dark:text-white">{trip.destination}</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-300">{trip.date}</p>
                  </div>
                  <div className="flex items-center space-x-1">
                    {[...Array(trip.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-amber-500 fill-current" />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Quick Actions */}
          <div className="grid grid-cols-2 gap-4">
            <Button className="h-16 bg-white/20 backdrop-blur-md border border-white/30 hover:bg-white/30 rounded-2xl">
              <div className="flex flex-col items-center space-y-1">
                <Heart className="w-6 h-6 text-red-600" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-200">My Favorites</span>
              </div>
            </Button>
            <Button className="h-16 bg-white/20 backdrop-blur-md border border-white/30 hover:bg-white/30 rounded-2xl">
              <div className="flex flex-col items-center space-y-1">
                <Calendar className="w-6 h-6 text-blue-600" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-200">Trip History</span>
              </div>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
