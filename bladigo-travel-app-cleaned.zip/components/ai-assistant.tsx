"use client"

import { useState, useRef, useEffect } from "react"
import { ArrowLeft, Send, Mic, MicOff, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useAI } from "@/components/ai-provider"

interface AIAssistantProps {
  onBack: () => void
}

export function AIAssistant({ onBack }: AIAssistantProps) {
  const { messages, addMessage, getAIResponse } = useAI()
  const [inputText, setInputText] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isListening, setIsListening] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  useEffect(() => {
    if (messages.length === 0) {
      addMessage(
        "Hello! I'm your AI travel assistant for Algeria. I can help you plan trips, find amazing destinations, recommend hotels, and answer any questions about traveling in Algeria. How can I assist you today? 🇩🇿✨",
        "assistant",
      )
    }
  }, [])

  const sendMessage = async () => {
    if (!inputText.trim() || isLoading) return

    const userMessage = inputText.trim()
    setInputText("")
    addMessage(userMessage, "user")
    setIsLoading(true)

    try {
      const response = await getAIResponse(userMessage)
      addMessage(response, "assistant")
    } catch (error) {
      addMessage("I apologize, but I'm having trouble responding right now. Please try again.", "assistant")
    } finally {
      setIsLoading(false)
    }
  }

  const startListening = () => {
    if ("webkitSpeechRecognition" in window) {
      const recognition = new (window as any).webkitSpeechRecognition()
      recognition.continuous = false
      recognition.interimResults = false
      recognition.lang = "en-US"

      recognition.onstart = () => setIsListening(true)
      recognition.onend = () => setIsListening(false)
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript
        setInputText(transcript)
      }

      recognition.start()
    }
  }

  const quickQuestions = [
    "Best places to visit in Algeria",
    "Traditional Algerian food recommendations",
    "Hotels in Algiers",
    "Plan a 3-day trip",
    "Weather in Algeria",
    "Cultural attractions",
  ]

  return (
    <div className="flex flex-col h-screen">
      {/* Header */}
      <div className="flex items-center justify-between p-6 pt-12 bg-white/10 dark:bg-black/10 backdrop-blur-xl border-b border-white/20">
        <Button
          onClick={onBack}
          className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
        >
          <ArrowLeft className="w-6 h-6 text-gray-700 dark:text-gray-200" />
        </Button>
        <div className="text-center">
          <div className="flex items-center space-x-2">
            <Sparkles className="w-6 h-6 text-purple-600 animate-pulse" />
            <h1 className="text-xl font-bold text-gray-800 dark:text-white">AI Assistant</h1>
          </div>
          <p className="text-sm text-gray-600 dark:text-gray-300">Your intelligent travel companion</p>
        </div>
        <div className="w-12"></div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.map((message) => (
          <div key={message.id} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[85%] p-4 rounded-2xl ${
                message.role === "user"
                  ? "bg-gradient-to-r from-blue-500 to-purple-500 text-white"
                  : "bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 text-gray-800 dark:text-white"
              }`}
            >
              {message.role === "assistant" && (
                <div className="flex items-center space-x-2 mb-2">
                  <Sparkles className="w-4 h-4 text-purple-600" />
                  <span className="text-xs font-medium text-purple-600">AI Assistant</span>
                </div>
              )}
              <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
              <p className={`text-xs mt-2 ${message.role === "user" ? "text-white/70" : "text-gray-500"}`}>
                {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
              </p>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-4">
              <div className="flex items-center space-x-2">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce delay-100"></div>
                  <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce delay-200"></div>
                </div>
                <span className="text-sm text-gray-600 dark:text-gray-300">AI is thinking...</span>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Questions */}
      {messages.length <= 1 && (
        <div className="p-6 pt-0">
          <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">Quick questions to get started:</p>
          <div className="grid grid-cols-2 gap-2">
            {quickQuestions.map((question, index) => (
              <Button
                key={index}
                onClick={() => setInputText(question)}
                className="bg-white/20 dark:bg-white/10 hover:bg-white/30 text-gray-700 dark:text-gray-200 rounded-xl p-3 text-xs text-left h-auto"
              >
                {question}
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Input Area */}
      <div className="p-6 bg-white/10 dark:bg-black/10 backdrop-blur-xl border-t border-white/20">
        <div className="flex items-center space-x-3">
          <div className="flex-1 bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl px-4 py-3">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && sendMessage()}
              placeholder="Ask me anything about Algeria..."
              className="w-full bg-transparent placeholder-gray-500 dark:placeholder-gray-400 text-gray-700 dark:text-gray-200 outline-none"
            />
          </div>
          <Button
            onClick={startListening}
            className={`backdrop-blur-md border border-white/30 rounded-full p-3 transition-all duration-300 ${
              isListening
                ? "bg-red-500 hover:bg-red-600 text-white animate-pulse"
                : "bg-white/20 dark:bg-white/10 hover:bg-white/30 text-gray-700 dark:text-gray-200"
            }`}
          >
            {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </Button>
          <Button
            onClick={sendMessage}
            disabled={!inputText.trim() || isLoading}
            className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 disabled:opacity-50 text-white rounded-full p-3"
          >
            <Send className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  )
}
