"use client"

import type React from "react"
import { createContext, useContext, useState } from "react"

interface AIMessage {
  id: string
  content: string
  role: "user" | "assistant"
  timestamp: Date
}

interface UserPreferences {
  interests: string[]
  budget: "budget" | "mid-range" | "luxury"
  travelStyle: "cultural" | "adventure" | "relaxation" | "mixed"
}

interface AIContextType {
  messages: AIMessage[]
  addMessage: (content: string, role: "user" | "assistant") => void
  clearMessages: () => void
  userPreferences: UserPreferences
  updatePreferences: (preferences: Partial<UserPreferences>) => void
  getAIResponse: (userMessage: string) => Promise<string>
}

const AIContext = createContext<AIContextType | undefined>(undefined)

export function AIProvider({ children }: { children: React.ReactNode }) {
  const [messages, setMessages] = useState<AIMessage[]>([])
  const [userPreferences, setUserPreferences] = useState<UserPreferences>({
    interests: [],
    budget: "mid-range",
    travelStyle: "mixed",
  })

  const addMessage = (content: string, role: "user" | "assistant") => {
    const newMessage: AIMessage = {
      id: Date.now().toString(),
      content,
      role,
      timestamp: new Date(),
    }
    setMessages((prev) => [...prev, newMessage])
  }

  const clearMessages = () => {
    setMessages([])
  }

  const updatePreferences = (preferences: Partial<UserPreferences>) => {
    setUserPreferences((prev) => ({ ...prev, ...preferences }))
  }

  const getAIResponse = async (userMessage: string): Promise<string> => {
    // Simulate AI processing delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const message = userMessage.toLowerCase()

    // Smart responses based on user preferences and message content
    if (message.includes("hotel") || message.includes("accommodation")) {
      const budgetRec = userPreferences.budget === "luxury" ? "5-star hotels" : "comfortable accommodations"
      return `Based on your ${userPreferences.budget} budget preference, I recommend ${budgetRec} in Algeria. Sofitel Algiers and Hotel El Aurassi are excellent choices. Would you like me to show availability and prices?`
    }

    if (message.includes("food") || message.includes("restaurant") || message.includes("cuisine")) {
      return `Algerian cuisine is incredible! Must-try dishes include Couscous, Tajine, Makroud, and Chorba. For authentic experiences, I recommend restaurants in the Casbah area of Algiers. Would you like specific restaurant recommendations based on your location?`
    }

    if (message.includes("place") || message.includes("visit") || message.includes("destination")) {
      const styleRec =
        userPreferences.travelStyle === "cultural"
          ? "cultural sites like Timgad ruins and the Casbah"
          : userPreferences.travelStyle === "adventure"
            ? "adventure spots like the Sahara Desert and Tassili n'Ajjer"
            : "a mix of cultural and natural attractions"
      return `For ${userPreferences.travelStyle} travel, I highly recommend ${styleRec}. Each offers unique experiences that match your interests. Which type of destination interests you most right now?`
    }

    if (message.includes("trip") || message.includes("plan") || message.includes("itinerary")) {
      return `I'd love to help plan your perfect Algeria trip! I can create a personalized itinerary based on your dates, budget, and interests. Just tell me: How many days will you be visiting, and what type of experiences are you most excited about?`
    }

    if (message.includes("weather") || message.includes("climate")) {
      return `Algeria has a Mediterranean climate along the coast and desert climate inland. The best time to visit is spring (March-May) and fall (September-November) for comfortable temperatures. Summer can be very hot, especially in the Sahara. Would you like specific weather info for your travel dates?`
    }

    // Default intelligent response
    return `That's a great question! I'm here to help you discover the best of Algeria. I can assist with trip planning, hotel recommendations, restaurant suggestions, cultural insights, and local tips. What aspect of your Algeria adventure would you like to explore first?`
  }

  return (
    <AIContext.Provider
      value={{
        messages,
        addMessage,
        clearMessages,
        userPreferences,
        updatePreferences,
        getAIResponse,
      }}
    >
      {children}
    </AIContext.Provider>
  )
}

export const useAI = () => {
  const context = useContext(AIContext)
  if (!context) {
    throw new Error("useAI must be used within AIProvider")
  }
  return context
}
