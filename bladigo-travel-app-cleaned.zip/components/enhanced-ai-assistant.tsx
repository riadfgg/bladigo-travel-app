"use client"

import { useState, useRef, useEffect } from "react"
import { ArrowLeft, Send, Mic, MicOff, Sparkles, MapPin, Calendar, DollarSign } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useAI } from "@/components/ai-provider"
import { useLocation } from "@/components/location-provider"
import { useLanguage } from "@/components/language-provider"

interface EnhancedAIAssistantProps {
  onBack: () => void
}

export function EnhancedAIAssistant({ onBack }: EnhancedAIAssistantProps) {
  const { messages, addMessage, getAIResponse } = useAI()
  const { location } = useLocation()
  const { t } = useLanguage()
  const [inputText, setInputText] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isListening, setIsListening] = useState(false)
  const [showSuggestions, setShowSuggestions] = useState(true)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  useEffect(() => {
    if (messages.length === 0) {
      const welcomeMessage = location
        ? `مرحباً! أنا مساعدك الذكي للسفر في الجزائر. أراك في موقع ${location.latitude.toFixed(2)}, ${location.longitude.toFixed(2)}. كيف يمكنني مساعدتك اليوم؟ 🇩🇿✨`
        : "مرحباً! أنا مساعدك الذكي للسفر في الجزائر. كيف يمكنني مساعدتك في التخطيط لرحلتك؟ 🇩🇿✨"

      addMessage(welcomeMessage, "assistant")
    }
  }, [location])

  const sendMessage = async () => {
    if (!inputText.trim() || isLoading) return

    const userMessage = inputText.trim()
    setInputText("")
    setShowSuggestions(false)
    addMessage(userMessage, "user")
    setIsLoading(true)

    try {
      const response = await getEnhancedAIResponse(userMessage)
      addMessage(response, "assistant")
    } catch (error) {
      addMessage("عذراً، أواجه مشكلة في الاستجابة الآن. يرجى المحاولة مرة أخرى.", "assistant")
    } finally {
      setIsLoading(false)
    }
  }

  const getEnhancedAIResponse = async (userMessage: string): Promise<string> => {
    await new Promise((resolve) => setTimeout(resolve, 1500))

    const message = userMessage.toLowerCase()
    const currentTime = new Date()
    const currentHour = currentTime.getHours()
    const currentSeason = getCurrentSeason()

    // Smart location-based responses
    if (location && (message.includes("قريب") || message.includes("near") || message.includes("حولي"))) {
      return `بناءً على موقعك الحالي، إليك أقرب الأماكن المميزة:

🏛️ **مقام الشهيد** - 2.3 كم (15 دقيقة سيراً)
🕌 **جامع كتشاوة** - 1.8 كم (12 دقيقة سيراً)  
🏨 **فندق الأوراسي** - 1.2 كم (8 دقائق سيراً)

الطقس الآن مناسب للتجول. هل تريد اتجاهات للوصول لأي من هذه الأماكن؟`
    }

    // Time-based recommendations
    if (message.includes("الآن") || message.includes("اليوم")) {
      if (currentHour < 10) {
        return `صباح الخير! الوقت مثالي لـ:
☕ **إفطار جزائري تقليدي** في مقهى شعبي
🌅 **زيارة مقام الشهيد** - أفضل إضاءة للصور
🚶‍♂️ **جولة في القصبة** قبل ازدحام النهار

درجة الحرارة: 22°م - مثالية للتجول!`
      } else if (currentHour < 15) {
        return `وقت الظهيرة رائع لـ:
🍽️ **غداء في مطعم تقليدي** - جرب الكسكس الجزائري
🏛️ **زيارة المتاحف** - مكيفة ومريحة
🛍️ **التسوق في الأسواق المحلية**

تجنب الشمس المباشرة بين 12-3 مساءً`
      } else {
        return `المساء مثالي لـ:
🌅 **مشاهدة الغروب** من حصن سانتا كروز
🍵 **شاي بالنعناع** في مقهى بإطلالة بحرية
🚶‍♀️ **نزهة على الكورنيش**

الجو لطيف الآن - استمتع بالهواء الطلق!`
      }
    }

    // Budget-based recommendations
    if (message.includes("رخيص") || message.includes("budget") || message.includes("اقتصادي")) {
      return `💰 **خيارات اقتصادية ممتازة:**

🏨 **إقامة:** نزل شبابية (1,500-3,000 دج/ليلة)
🍽️ **طعام:** مطاعم شعبية (300-800 دج/وجبة)
🚌 **مواصلات:** حافلات عامة (30-50 دج)
🎫 **مواقع:** معظم المواقع التاريخية مجانية!

**ميزانية يومية مقترحة:** 2,500-4,000 دج للشخص`
    }

    // Season-based recommendations
    if (message.includes("متى") || message.includes("when") || message.includes("أفضل وقت")) {
      return `🗓️ **أفضل أوقات زيارة الجزائر:**

🌸 **الربيع (مارس-مايو):** مثالي! طقس معتدل وطبيعة خضراء
☀️ **الصيف (يونيو-أغسطس):** حار، لكن رائع للشواطئ
🍂 **الخريف (سبتمبر-نوفمبر):** ممتاز للسياحة الثقافية
❄️ **الشتاء (ديسمبر-فبراير):** بارد، لكن أقل ازدحاماً

**الآن في ${currentSeason}** - ${getSeasonAdvice(currentSeason)}`
    }

    // Default enhanced response
    return `أفهم استفسارك! إليك بعض الاقتراحات المخصصة:

🎯 **بناءً على اهتماماتك:**
- إذا كنت تحب التاريخ: القصبة، تيمقاد، جميلة
- إذا كنت تحب الطبيعة: الصحراء، الأطلس، الساحل
- إذا كنت تحب الثقافة: المتاحف، المهرجانات، الأسواق

💡 **نصيحة ذكية:** استخدم خريطة جوجل المدمجة لرؤية المسافات والاتجاهات!

هل تريد تفاصيل أكثر عن أي من هذه الخيارات؟`
  }

  const getCurrentSeason = () => {
    const month = new Date().getMonth()
    if (month >= 2 && month <= 4) return "الربيع"
    if (month >= 5 && month <= 7) return "الصيف"
    if (month >= 8 && month <= 10) return "الخريف"
    return "الشتاء"
  }

  const getSeasonAdvice = (season: string) => {
    switch (season) {
      case "الربيع":
        return "وقت مثالي للزيارة! 🌸"
      case "الصيف":
        return "حار، اشرب الكثير من الماء! ☀️"
      case "الخريف":
        return "طقس رائع للاستكشاف! 🍂"
      case "الشتاء":
        return "بارد، لكن أقل ازدحاماً! ❄️"
      default:
        return "استمتع برحلتك! ✨"
    }
  }

  const startListening = () => {
    if ("webkitSpeechRecognition" in window) {
      const recognition = new (window as any).webkitSpeechRecognition()
      recognition.continuous = false
      recognition.interimResults = false
      recognition.lang = "ar-DZ"

      recognition.onstart = () => setIsListening(true)
      recognition.onend = () => setIsListening(false)
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript
        setInputText(transcript)
      }

      recognition.start()
    }
  }

  const smartSuggestions = [
    { icon: "🏛️", text: "أماكن تاريخية قريبة مني", category: "history" },
    { icon: "🍽️", text: "أفضل مطاعم الطعام الجزائري", category: "food" },
    { icon: "🏨", text: "فنادق بميزانية محدودة", category: "budget" },
    { icon: "🗓️", text: "خطط لي رحلة 3 أيام", category: "planning" },
    { icon: "🌤️", text: "ما هو أفضل وقت للزيارة؟", category: "weather" },
    { icon: "🚗", text: "كيف أتنقل في الجزائر؟", category: "transport" },
  ]

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-blue-900">
      {/* Enhanced Header */}
      <div className="flex items-center justify-between p-6 pt-12 bg-white/10 dark:bg-black/10 backdrop-blur-xl border-b border-white/20">
        <Button
          onClick={onBack}
          className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
        >
          <ArrowLeft className="w-6 h-6 text-gray-700 dark:text-gray-200" />
        </Button>
        <div className="text-center">
          <div className="flex items-center space-x-2">
            <Sparkles className="w-6 h-6 text-purple-600 animate-pulse" />
            <h1 className="text-xl font-bold text-gray-800 dark:text-white">مساعد السفر الذكي</h1>
          </div>
          <p className="text-sm text-gray-600 dark:text-gray-300">مدعوم بالذكاء الاصطناعي</p>
        </div>
        <div className="w-12"></div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.map((message) => (
          <div key={message.id} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[85%] p-4 rounded-2xl ${
                message.role === "user"
                  ? "bg-gradient-to-r from-blue-500 to-purple-500 text-white"
                  : "bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 text-gray-800 dark:text-white"
              }`}
            >
              {message.role === "assistant" && (
                <div className="flex items-center space-x-2 mb-2">
                  <Sparkles className="w-4 h-4 text-purple-600" />
                  <span className="text-xs font-medium text-purple-600">مساعد ذكي</span>
                </div>
              )}
              <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
              <p className={`text-xs mt-2 ${message.role === "user" ? "text-white/70" : "text-gray-500"}`}>
                {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
              </p>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-4">
              <div className="flex items-center space-x-2">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce delay-100"></div>
                  <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce delay-200"></div>
                </div>
                <span className="text-sm text-gray-600 dark:text-gray-300">الذكي الاصطناعي يفكر...</span>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Smart Suggestions */}
      {showSuggestions && messages.length <= 1 && (
        <div className="p-6 pt-0">
          <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">اقتراحات ذكية:</p>
          <div className="grid grid-cols-1 gap-2">
            {smartSuggestions.map((suggestion, index) => (
              <Button
                key={index}
                onClick={() => setInputText(suggestion.text)}
                className="bg-white/20 dark:bg-white/10 hover:bg-white/30 text-gray-700 dark:text-gray-200 rounded-xl p-3 text-sm text-left h-auto justify-start"
              >
                <span className="mr-2">{suggestion.icon}</span>
                {suggestion.text}
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Enhanced Input Area */}
      <div className="p-6 bg-white/10 dark:bg-black/10 backdrop-blur-xl border-t border-white/20">
        <div className="flex items-center space-x-3">
          <div className="flex-1 bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl px-4 py-3">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && sendMessage()}
              placeholder="اسألني أي شيء عن السفر في الجزائر..."
              className="w-full bg-transparent placeholder-gray-500 dark:placeholder-gray-400 text-gray-700 dark:text-gray-200 outline-none"
            />
          </div>
          <Button
            onClick={startListening}
            className={`backdrop-blur-md border border-white/30 rounded-full p-3 transition-all duration-300 ${
              isListening
                ? "bg-red-500 hover:bg-red-600 text-white animate-pulse"
                : "bg-white/20 dark:bg-white/10 hover:bg-white/30 text-gray-700 dark:text-gray-200"
            }`}
          >
            {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </Button>
          <Button
            onClick={sendMessage}
            disabled={!inputText.trim() || isLoading}
            className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 disabled:opacity-50 text-white rounded-full p-3"
          >
            <Send className="w-5 h-5" />
          </Button>
        </div>

        {/* Quick Actions */}
        <div className="flex items-center justify-center space-x-4 mt-3">
          <Button
            onClick={() => setInputText("أماكن قريبة مني")}
            className="bg-white/10 hover:bg-white/20 text-gray-600 dark:text-gray-300 rounded-full px-3 py-1 text-xs"
          >
            <MapPin className="w-3 h-3 mr-1" />
            قريب مني
          </Button>
          <Button
            onClick={() => setInputText("خطط لي رحلة")}
            className="bg-white/10 hover:bg-white/20 text-gray-600 dark:text-gray-300 rounded-full px-3 py-1 text-xs"
          >
            <Calendar className="w-3 h-3 mr-1" />
            خطط رحلة
          </Button>
          <Button
            onClick={() => setInputText("ميزانية محدودة")}
            className="bg-white/10 hover:bg-white/20 text-gray-600 dark:text-gray-300 rounded-full px-3 py-1 text-xs"
          >
            <DollarSign className="w-3 h-3 mr-1" />
            اقتصادي
          </Button>
        </div>
      </div>
    </div>
  )
}
