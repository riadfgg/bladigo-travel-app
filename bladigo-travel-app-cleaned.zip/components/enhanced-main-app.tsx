"use client"

import { useState, useEffect } from "react"
import { MapPin, Hotel, Home, User, Settings, MessageCircle, Calendar, Navigation, Bell, Filter } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { TouristSpotsSection } from "@/components/tourist-spots-section"
import { HotelsSection } from "@/components/hotels-section"
import { AccountSection } from "@/components/account-section"
import { SettingsSection } from "@/components/settings-section"
import { EnhancedAIAssistant } from "@/components/enhanced-ai-assistant"
import { EnhancedTripPlanner } from "@/components/enhanced-trip-planner"
import { FloatingMapButton } from "@/components/floating-map-button"
import { StickyHeader } from "@/components/sticky-header"
import { useLocation } from "@/components/location-provider"
import { useLanguage } from "@/components/language-provider"

type ActiveSection = "home" | "tourist-spots" | "hotels" | "account" | "settings" | "ai-assistant" | "trip-planner"

export function EnhancedMainApp() {
  const [activeSection, setActiveSection] = useState<ActiveSection>("home")
  const [searchQuery, setSearchQuery] = useState("")
  const [showNotification, setShowNotification] = useState(false)
  const [selectedFilters, setSelectedFilters] = useState<string[]>([])
  const { location } = useLocation()
  const { t, isRTL } = useLanguage()

  // Smart geo-notifications
  useEffect(() => {
    if (location) {
      const timer = setTimeout(() => {
        setShowNotification(true)
        setTimeout(() => setShowNotification(false), 6000)
      }, 3000)
      return () => clearTimeout(timer)
    }
  }, [location])

  const filters = [
    { id: "family", name: "عائلي", icon: "👨‍👩‍👧‍👦" },
    { id: "nature", name: "طبيعة", icon: "🌿" },
    { id: "historical", name: "تاريخي", icon: "🏛️" },
    { id: "beach", name: "شاطئ", icon: "🏖️" },
    { id: "adventure", name: "مغامرة", icon: "🏔️" },
    { id: "culture", name: "ثقافة", icon: "🎭" },
  ]

  const toggleFilter = (filterId: string) => {
    setSelectedFilters((prev) => (prev.includes(filterId) ? prev.filter((id) => id !== filterId) : [...prev, filterId]))
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-blue-50 to-emerald-50 dark:from-gray-900 dark:via-blue-900 dark:to-emerald-900 transition-colors duration-500">
      {/* Sticky Header */}
      <StickyHeader
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onNavigate={setActiveSection}
        showNotifications={true}
      />

      {/* Floating Background Elements */}
      <div className="fixed top-20 left-10 w-32 h-32 bg-amber-300/20 rounded-full blur-xl animate-float pointer-events-none"></div>
      <div className="fixed bottom-40 right-10 w-40 h-40 bg-blue-300/20 rounded-full blur-xl animate-float-delayed pointer-events-none"></div>
      <div className="fixed top-1/3 right-20 w-24 h-24 bg-emerald-300/20 rounded-full blur-xl animate-float pointer-events-none"></div>

      {/* Smart Notification */}
      {showNotification && (
        <div className="fixed top-20 left-4 right-4 z-50 animate-in slide-in-from-top duration-500">
          <div className="bg-gradient-to-r from-emerald-500/90 to-teal-500/90 backdrop-blur-xl border border-white/30 rounded-2xl p-4 shadow-2xl">
            <div className="flex items-center space-x-3">
              <Bell className="w-5 h-5 text-white animate-pulse" />
              <div>
                <p className="text-white font-medium">
                  📍 {isRTL ? "أنت بالقرب من وسط الجزائر!" : "You're near Algiers Center!"}
                </p>
                <p className="text-white/80 text-sm">
                  {isRTL ? "3 معالم مذهلة في نطاق 2 كم" : "3 amazing attractions within 2km"}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="pt-32 pb-24">
        {activeSection === "home" && (
          <div className="p-6 space-y-8">
            {/* Welcome Section */}
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-800 dark:text-white mb-2">{t("home.welcome")}</h2>
              <p className="text-gray-600 dark:text-gray-300">{t("home.subtitle")}</p>
            </div>

            {/* Smart Filters */}
            <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-4">
              <div className="flex items-center space-x-3 mb-3">
                <Filter className="w-5 h-5 text-purple-600" />
                <h3 className="font-bold text-gray-800 dark:text-white">فلترة ذكية</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {filters.map((filter) => (
                  <Button
                    key={filter.id}
                    onClick={() => toggleFilter(filter.id)}
                    className={`rounded-full px-3 py-1 text-sm transition-all duration-300 ${
                      selectedFilters.includes(filter.id)
                        ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white"
                        : "bg-white/20 hover:bg-white/30 text-gray-700 dark:text-gray-200"
                    }`}
                  >
                    <span className="mr-1">{filter.icon}</span>
                    {filter.name}
                  </Button>
                ))}
              </div>
            </Card>

            {/* Main Action Buttons */}
            <div className="space-y-4">
              <Button
                onClick={() => setActiveSection("tourist-spots")}
                className="w-full h-24 bg-gradient-to-r from-amber-500/80 to-orange-500/80 backdrop-blur-md border border-white/30 hover:from-amber-600/80 hover:to-orange-600/80 transition-all duration-300 rounded-2xl shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                <div className="flex items-center space-x-4">
                  <MapPin className="w-10 h-10 text-white" />
                  <div className="text-left">
                    <h3 className="text-2xl font-bold text-white">{t("home.discover_places")}</h3>
                    <p className="text-white/80">{t("home.discover_subtitle")}</p>
                  </div>
                </div>
              </Button>

              <Button
                onClick={() => setActiveSection("hotels")}
                className="w-full h-24 bg-gradient-to-r from-blue-500/80 to-cyan-500/80 backdrop-blur-md border border-white/30 hover:from-blue-600/80 hover:to-cyan-600/80 transition-all duration-300 rounded-2xl shadow-lg hover:shadow-xl transform hover:scale-105"
              >
                <div className="flex items-center space-x-4">
                  <Hotel className="w-10 h-10 text-white" />
                  <div className="text-left">
                    <h3 className="text-2xl font-bold text-white">{t("home.find_hotels")}</h3>
                    <p className="text-white/80">{t("home.find_hotels_subtitle")}</p>
                  </div>
                </div>
              </Button>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-2 gap-4">
              <Button
                onClick={() => setActiveSection("ai-assistant")}
                className="h-20 bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-2xl"
              >
                <div className="flex flex-col items-center space-y-2">
                  <MessageCircle className="w-8 h-8 text-purple-600" />
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-200">مساعد ذكي</span>
                </div>
              </Button>

              <Button
                onClick={() => setActiveSection("trip-planner")}
                className="h-20 bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-2xl"
              >
                <div className="flex flex-col items-center space-y-2">
                  <Calendar className="w-8 h-8 text-emerald-600" />
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-200">مخطط الرحلات</span>
                </div>
              </Button>
            </div>

            {/* Enhanced Stats */}
            <div className="grid grid-cols-3 gap-4">
              <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-4 text-center">
                <div className="text-2xl font-bold text-amber-600 mb-1">150+</div>
                <div className="text-sm text-gray-600 dark:text-gray-300">{t("home.destinations")}</div>
              </Card>
              <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-4 text-center">
                <div className="text-2xl font-bold text-blue-600 mb-1">500+</div>
                <div className="text-sm text-gray-600 dark:text-gray-300">{t("home.hotels")}</div>
              </Card>
              <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-4 text-center">
                <div className="text-2xl font-bold text-emerald-600 mb-1">4.9★</div>
                <div className="text-sm text-gray-600 dark:text-gray-300">{t("home.rating")}</div>
              </Card>
            </div>

            {/* Trending Places */}
            <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
              <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">🔥 الأماكن الرائجة</h3>
              <div className="space-y-3">
                {[
                  { name: "مقام الشهيد", views: "12.5k", trend: "+15%" },
                  { name: "القصبة العتيقة", views: "8.2k", trend: "+8%" },
                  { name: "تيمقاد الأثرية", views: "6.7k", trend: "+12%" },
                ].map((place, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-white/10 rounded-xl">
                    <div>
                      <p className="font-medium text-gray-800 dark:text-white">{place.name}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-300">{place.views} مشاهدة</p>
                    </div>
                    <div className="text-green-600 font-bold text-sm">{place.trend}</div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        )}

        {activeSection === "tourist-spots" && <TouristSpotsSection onBack={() => setActiveSection("home")} />}
        {activeSection === "hotels" && <HotelsSection onBack={() => setActiveSection("home")} />}
        {activeSection === "account" && <AccountSection onBack={() => setActiveSection("home")} />}
        {activeSection === "settings" && <SettingsSection onBack={() => setActiveSection("home")} />}
        {activeSection === "ai-assistant" && <EnhancedAIAssistant onBack={() => setActiveSection("home")} />}
        {activeSection === "trip-planner" && <EnhancedTripPlanner onBack={() => setActiveSection("home")} />}
      </div>

      {/* Enhanced Bottom Navigation */}
      <div className="fixed bottom-6 left-6 right-6 z-20">
        <div className="bg-white/20 dark:bg-white/10 backdrop-blur-xl border border-white/30 rounded-2xl shadow-2xl">
          <div className="flex justify-around py-4">
            <Button
              onClick={() => setActiveSection("home")}
              className={`transition-all duration-300 rounded-xl p-3 ${
                activeSection === "home"
                  ? "bg-gradient-to-r from-blue-500 to-purple-500 text-white"
                  : "bg-transparent hover:bg-white/20 text-gray-600 dark:text-gray-300"
              }`}
            >
              <Home className="w-6 h-6" />
            </Button>
            <Button
              onClick={() => {
                const googleMapsUrl =
                  "https://www.google.com/maps/search/tourist+attractions+algeria/@28.0339,-1.6596,6z"
                window.open(googleMapsUrl, "_blank")
              }}
              className="bg-transparent hover:bg-white/20 text-gray-600 dark:text-gray-300 transition-all duration-300 rounded-xl p-3"
            >
              <MapPin className="w-6 h-6" />
            </Button>
            <Button
              onClick={() => setActiveSection("account")}
              className={`transition-all duration-300 rounded-xl p-3 ${
                activeSection === "account"
                  ? "bg-gradient-to-r from-blue-500 to-purple-500 text-white"
                  : "bg-transparent hover:bg-white/20 text-gray-600 dark:text-gray-300"
              }`}
            >
              <User className="w-6 h-6" />
            </Button>
            <Button
              onClick={() => setActiveSection("settings")}
              className={`transition-all duration-300 rounded-xl p-3 ${
                activeSection === "settings"
                  ? "bg-gradient-to-r from-blue-500 to-purple-500 text-white"
                  : "bg-transparent hover:bg-white/20 text-gray-600 dark:text-gray-300"
              }`}
            >
              <Settings className="w-6 h-6" />
            </Button>
          </div>
        </div>
      </div>

      {/* Floating Map Button */}
      <FloatingMapButton />

      {/* Floating GPS Button */}
      {location && (
        <div className="fixed bottom-32 right-6 z-20">
          <Button className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white rounded-full p-4 shadow-2xl animate-pulse">
            <Navigation className="w-6 h-6" />
          </Button>
        </div>
      )}
    </div>
  )
}
