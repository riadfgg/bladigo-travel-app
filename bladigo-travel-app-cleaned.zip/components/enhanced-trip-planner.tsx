"use client"

import { useState } from "react"
import { ArrowLeft, Calendar, MapPin, DollarSign, Clock, Download, Sparkles, Save, Share2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { useLanguage } from "@/components/language-provider"

interface EnhancedTripPlannerProps {
  onBack: () => void
}

interface TripPlan {
  day: number
  date: string
  activities: {
    time: string
    activity: string
    location: string
    duration: string
    cost: string
    coordinates: { lat: number; lng: number }
    category: string
    rating: number
  }[]
  totalCost: string
  weather: string
}

export function EnhancedTripPlanner({ onBack }: EnhancedTripPlannerProps) {
  const [step, setStep] = useState(1)
  const [tripData, setTripData] = useState({
    destination: "",
    duration: "",
    travelers: "",
    budget: "",
    interests: [] as string[],
    dates: { start: "", end: "" },
    accommodation: "",
    transport: "",
    travelStyle: "",
  })
  const [generatedPlan, setGeneratedPlan] = useState<TripPlan[]>([])
  const [isGenerating, setIsGenerating] = useState(false)
  const [savedPlans, setSavedPlans] = useState<any[]>([])
  const { t } = useLanguage()

  const destinations = [
    { id: "algiers", name: "الجزائر العاصمة", icon: "🏛️" },
    { id: "oran", name: "وهران", icon: "🌊" },
    { id: "constantine", name: "قسنطينة", icon: "🌉" },
    { id: "batna", name: "باتنة", icon: "🏔️" },
    { id: "tlemcen", name: "تلمسان", icon: "🕌" },
    { id: "ghardaia", name: "غرداية", icon: "🏜️" },
    { id: "tamanrasset", name: "تمنراست", icon: "🐪" },
  ]

  const durations = [
    { id: "1-2", name: "1-2 أيام", icon: "⚡" },
    { id: "3-5", name: "3-5 أيام", icon: "📅" },
    { id: "1-week", name: "أسبوع", icon: "🗓️" },
    { id: "2-weeks", name: "أسبوعين", icon: "📆" },
    { id: "1-month", name: "شهر", icon: "🗓️" },
  ]

  const budgetRanges = [
    { id: "budget", name: "اقتصادي", range: "2,000-5,000 دج/يوم", icon: "💰" },
    { id: "mid", name: "متوسط", range: "5,000-10,000 دج/يوم", icon: "💳" },
    { id: "luxury", name: "فاخر", range: "10,000+ دج/يوم", icon: "💎" },
  ]

  const interestOptions = [
    { id: "history", name: "التاريخ", icon: "🏛️" },
    { id: "culture", name: "الثقافة", icon: "🎭" },
    { id: "nature", name: "الطبيعة", icon: "🌿" },
    { id: "food", name: "الطعام", icon: "🍽️" },
    { id: "adventure", name: "المغامرة", icon: "🏔️" },
    { id: "relaxation", name: "الاسترخاء", icon: "🧘‍♀️" },
    { id: "photography", name: "التصوير", icon: "📸" },
    { id: "shopping", name: "التسوق", icon: "🛍️" },
    { id: "beach", name: "الشاطئ", icon: "🏖️" },
    { id: "desert", name: "الصحراء", icon: "🏜️" },
  ]

  const accommodationTypes = [
    { id: "hotel", name: "فندق", icon: "🏨" },
    { id: "hostel", name: "نزل", icon: "🏠" },
    { id: "apartment", name: "شقة", icon: "🏢" },
    { id: "camping", name: "تخييم", icon: "⛺" },
  ]

  const transportTypes = [
    { id: "car", name: "سيارة", icon: "🚗" },
    { id: "bus", name: "حافلة", icon: "🚌" },
    { id: "train", name: "قطار", icon: "🚂" },
    { id: "plane", name: "طائرة", icon: "✈️" },
  ]

  const travelStyles = [
    { id: "solo", name: "فردي", icon: "🚶‍♂️" },
    { id: "couple", name: "زوجين", icon: "💑" },
    { id: "family", name: "عائلة", icon: "👨‍👩‍👧‍👦" },
    { id: "friends", name: "أصدقاء", icon: "👥" },
    { id: "group", name: "مجموعة", icon: "👫" },
  ]

  const toggleInterest = (interest: string) => {
    setTripData((prev) => ({
      ...prev,
      interests: prev.interests.includes(interest)
        ? prev.interests.filter((i) => i !== interest)
        : [...prev.interests, interest],
    }))
  }

  const generateTrip = async () => {
    setIsGenerating(true)
    await new Promise((resolve) => setTimeout(resolve, 4000))

    const startDate = new Date(tripData.dates.start)
    const endDate = new Date(tripData.dates.end)
    const daysDiff = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24))

    const samplePlan: TripPlan[] = Array.from({ length: Math.min(daysDiff, 7) }, (_, index) => {
      const currentDate = new Date(startDate)
      currentDate.setDate(startDate.getDate() + index)

      return {
        day: index + 1,
        date: currentDate.toLocaleDateString("ar-DZ"),
        weather: index % 2 === 0 ? "مشمس 25°م" : "غائم جزئياً 22°م",
        activities: [
          {
            time: "09:00",
            activity: index === 0 ? "الوصول وتسجيل الدخول" : "إفطار في مقهى محلي",
            location: index === 0 ? "الفندق" : "مقهى الأندلس",
            duration: "1 ساعة",
            cost: index === 0 ? "0 دج" : "500 دج",
            coordinates: { lat: 36.7538, lng: 3.0588 },
            category: "accommodation",
            rating: 4.5,
          },
          {
            time: "10:30",
            activity: getActivityByInterest(tripData.interests[0] || "history", index),
            location: getLocationByInterest(tripData.interests[0] || "history", index),
            duration: "3 ساعات",
            cost: "1,500 دج",
            coordinates: { lat: 36.7538, lng: 3.0588 },
            category: tripData.interests[0] || "history",
            rating: 4.8,
          },
          {
            time: "14:00",
            activity: "غداء تقليدي",
            location: "مطعم دار الضيافة",
            duration: "1.5 ساعة",
            cost: "2,500 دج",
            coordinates: { lat: 36.7538, lng: 3.0588 },
            category: "food",
            rating: 4.6,
          },
          {
            time: "16:00",
            activity: getActivityByInterest(tripData.interests[1] || "culture", index),
            location: getLocationByInterest(tripData.interests[1] || "culture", index),
            duration: "2 ساعات",
            cost: "1,000 دج",
            coordinates: { lat: 36.7538, lng: 3.0588 },
            category: tripData.interests[1] || "culture",
            rating: 4.7,
          },
          {
            time: "19:00",
            activity: "عشاء مع إطلالة",
            location: "مطعم البحر الأبيض",
            duration: "2 ساعات",
            cost: "3,000 دج",
            coordinates: { lat: 36.7538, lng: 3.0588 },
            category: "food",
            rating: 4.9,
          },
        ],
        totalCost: "8,500 دج",
      }
    })

    setGeneratedPlan(samplePlan)
    setIsGenerating(false)
    setStep(4)
  }

  const getActivityByInterest = (interest: string, dayIndex: number) => {
    const activities = {
      history: ["زيارة مقام الشهيد", "استكشاف القصبة", "جولة في تيمقاد", "زيارة جميلة"],
      culture: ["زيارة المتحف الوطني", "جولة في الأسواق التقليدية", "حضور عرض فولكلوري", "زيارة دار الثقافة"],
      nature: ["نزهة في الحديقة النباتية", "رحلة إلى الأطلس", "زيارة الغابات", "استكشاف الواحات"],
      food: ["جولة طعام الشارع", "ورشة طبخ تقليدية", "زيارة السوق المحلي", "تذوق الحلويات"],
      adventure: ["تسلق الجبال", "رحلة صحراوية", "رياضة مائية", "استكشاف الكهوف"],
      beach: ["يوم على الشاطئ", "رياضة مائية", "نزهة ساحلية", "غروب البحر"],
    }
    return activities[interest as keyof typeof activities]?.[dayIndex % 4] || "نشاط مميز"
  }

  const getLocationByInterest = (interest: string, dayIndex: number) => {
    const locations = {
      history: ["مقام الشهيد", "القصبة العتيقة", "موقع تيمقاد", "موقع جميلة"],
      culture: ["المتحف الوطني", "سوق الجمعة", "دار الأوبرا", "المركز الثقافي"],
      nature: ["الحديقة النباتية", "جبال الأطلس", "غابة بعبدة", "واحة غرداية"],
      food: ["شارع ديدوش مراد", "بيت الطبخ", "السوق المركزي", "حي القصبة"],
      adventure: ["جبال الهقار", "صحراء تاسيلي", "شاطئ تيبازة", "كهوف بني عباس"],
      beach: ["شاطئ الجزائر", "خليج وهران", "ساحل بجاية", "شاطئ عنابة"],
    }
    return locations[interest as keyof typeof locations]?.[dayIndex % 4] || "موقع مميز"
  }

  const savePlan = () => {
    const planToSave = {
      id: Date.now(),
      name: `رحلة ${tripData.destination} - ${tripData.duration}`,
      destination: tripData.destination,
      dates: tripData.dates,
      plan: generatedPlan,
      createdAt: new Date().toISOString(),
    }
    setSavedPlans((prev) => [...prev, planToSave])
    alert("تم حفظ الخطة بنجاح!")
  }

  const exportPlan = () => {
    const planText = generatedPlan
      .map(
        (day) =>
          `اليوم ${day.day} - ${day.date}\n${day.activities
            .map((activity) => `${activity.time}: ${activity.activity} في ${activity.location} (${activity.cost})`)
            .join("\n")}\nالمجموع: ${day.totalCost}\n\n`,
      )
      .join("")

    const blob = new Blob([planText], { type: "text/plain;charset=utf-8" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `خطة-رحلة-${tripData.destination}.txt`
    a.click()
  }

  const sharePlan = () => {
    if (navigator.share) {
      navigator.share({
        title: `خطة رحلة ${tripData.destination}`,
        text: `شاهد خطة رحلتي إلى ${tripData.destination} مع BladiGo!`,
        url: window.location.href,
      })
    } else {
      navigator.clipboard.writeText(window.location.href)
      alert("تم نسخ رابط الخطة!")
    }
  }

  // Step 1: Basic Info
  if (step === 1) {
    return (
      <div className="p-6 space-y-6 bg-gradient-to-br from-emerald-50 to-blue-50 dark:from-gray-900 dark:to-emerald-900 min-h-screen">
        <div className="flex items-center justify-between">
          <Button
            onClick={onBack}
            className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
          >
            <ArrowLeft className="w-6 h-6 text-gray-700 dark:text-gray-200" />
          </Button>
          <div className="text-center">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-6 h-6 text-emerald-600 animate-pulse" />
              <h1 className="text-xl font-bold text-gray-800 dark:text-white">مخطط الرحلات الذكي</h1>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-300">الخطوة 1 من 3</p>
          </div>
          <div className="w-12"></div>
        </div>

        <div className="space-y-6">
          {/* Destination */}
          <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
            <div className="flex items-center space-x-3 mb-4">
              <MapPin className="w-6 h-6 text-emerald-600" />
              <h3 className="text-lg font-bold text-gray-800 dark:text-white">الوجهة</h3>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {destinations.map((destination) => (
                <Button
                  key={destination.id}
                  onClick={() => setTripData((prev) => ({ ...prev, destination: destination.name }))}
                  className={`p-4 rounded-xl transition-all duration-300 ${
                    tripData.destination === destination.name
                      ? "bg-gradient-to-r from-emerald-500 to-teal-500 text-white"
                      : "bg-white/20 dark:bg-white/10 hover:bg-white/30 text-gray-700 dark:text-gray-200"
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <span className="text-xl">{destination.icon}</span>
                    <span className="text-sm font-medium">{destination.name}</span>
                  </div>
                </Button>
              ))}
            </div>
          </Card>

          {/* Duration */}
          <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
            <div className="flex items-center space-x-3 mb-4">
              <Calendar className="w-6 h-6 text-blue-600" />
              <h3 className="text-lg font-bold text-gray-800 dark:text-white">مدة الرحلة</h3>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {durations.map((duration) => (
                <Button
                  key={duration.id}
                  onClick={() => setTripData((prev) => ({ ...prev, duration: duration.name }))}
                  className={`p-4 rounded-xl transition-all duration-300 ${
                    tripData.duration === duration.name
                      ? "bg-gradient-to-r from-blue-500 to-cyan-500 text-white"
                      : "bg-white/20 dark:bg-white/10 hover:bg-white/30 text-gray-700 dark:text-gray-200"
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <span className="text-xl">{duration.icon}</span>
                    <span className="text-sm font-medium">{duration.name}</span>
                  </div>
                </Button>
              ))}
            </div>
          </Card>

          {/* Travel Dates */}
          <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">تواريخ السفر</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">تاريخ البداية</label>
                <input
                  type="date"
                  value={tripData.dates.start}
                  onChange={(e) =>
                    setTripData((prev) => ({ ...prev, dates: { ...prev.dates, start: e.target.value } }))
                  }
                  className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">تاريخ النهاية</label>
                <input
                  type="date"
                  value={tripData.dates.end}
                  onChange={(e) => setTripData((prev) => ({ ...prev, dates: { ...prev.dates, end: e.target.value } }))}
                  className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          </Card>

          <Button
            onClick={() => setStep(2)}
            disabled={!tripData.destination || !tripData.duration || !tripData.dates.start || !tripData.dates.end}
            className="w-full h-16 bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-600 hover:via-teal-600 hover:to-cyan-600 disabled:opacity-50 text-white rounded-2xl shadow-lg"
          >
            <span className="text-lg font-bold">التالي: التفضيلات</span>
          </Button>
        </div>
      </div>
    )
  }

  // Step 2: Preferences
  if (step === 2) {
    return (
      <div className="p-6 space-y-6 bg-gradient-to-br from-purple-50 to-pink-50 dark:from-gray-900 dark:to-purple-900 min-h-screen">
        <div className="flex items-center justify-between">
          <Button
            onClick={() => setStep(1)}
            className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
          >
            <ArrowLeft className="w-6 h-6 text-gray-700 dark:text-gray-200" />
          </Button>
          <div className="text-center">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-6 h-6 text-purple-600 animate-pulse" />
              <h1 className="text-xl font-bold text-gray-800 dark:text-white">التفضيلات والاهتمامات</h1>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-300">الخطوة 2 من 3</p>
          </div>
          <div className="w-12"></div>
        </div>

        <div className="space-y-6">
          {/* Budget */}
          <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
            <div className="flex items-center space-x-3 mb-4">
              <DollarSign className="w-6 h-6 text-green-600" />
              <h3 className="text-lg font-bold text-gray-800 dark:text-white">الميزانية</h3>
            </div>
            <div className="space-y-3">
              {budgetRanges.map((budget) => (
                <Button
                  key={budget.id}
                  onClick={() => setTripData((prev) => ({ ...prev, budget: budget.name }))}
                  className={`w-full p-4 rounded-xl transition-all duration-300 ${
                    tripData.budget === budget.name
                      ? "bg-gradient-to-r from-green-500 to-emerald-500 text-white"
                      : "bg-white/20 dark:bg-white/10 hover:bg-white/30 text-gray-700 dark:text-gray-200"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <span className="text-xl">{budget.icon}</span>
                      <div className="text-left">
                        <p className="font-medium">{budget.name}</p>
                        <p className="text-sm opacity-80">{budget.range}</p>
                      </div>
                    </div>
                  </div>
                </Button>
              ))}
            </div>
          </Card>

          {/* Interests */}
          <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">اهتماماتك (اختر عدة خيارات)</h3>
            <div className="grid grid-cols-2 gap-3">
              {interestOptions.map((interest) => (
                <Button
                  key={interest.id}
                  onClick={() => toggleInterest(interest.id)}
                  className={`p-4 rounded-xl transition-all duration-300 ${
                    tripData.interests.includes(interest.id)
                      ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white"
                      : "bg-white/20 dark:bg-white/10 hover:bg-white/30 text-gray-700 dark:text-gray-200"
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <span className="text-xl">{interest.icon}</span>
                    <span className="text-sm font-medium">{interest.name}</span>
                  </div>
                </Button>
              ))}
            </div>
          </Card>

          <Button
            onClick={() => setStep(3)}
            disabled={tripData.interests.length === 0 || !tripData.budget}
            className="w-full h-16 bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 hover:from-purple-600 hover:via-pink-600 hover:to-red-600 disabled:opacity-50 text-white rounded-2xl shadow-lg"
          >
            <span className="text-lg font-bold">التالي: التفاصيل النهائية</span>
          </Button>
        </div>
      </div>
    )
  }

  // Step 3: Final Details
  if (step === 3) {
    return (
      <div className="p-6 space-y-6 bg-gradient-to-br from-orange-50 to-red-50 dark:from-gray-900 dark:to-orange-900 min-h-screen">
        <div className="flex items-center justify-between">
          <Button
            onClick={() => setStep(2)}
            className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
          >
            <ArrowLeft className="w-6 h-6 text-gray-700 dark:text-gray-200" />
          </Button>
          <div className="text-center">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-6 h-6 text-orange-600 animate-pulse" />
              <h1 className="text-xl font-bold text-gray-800 dark:text-white">التفاصيل النهائية</h1>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-300">الخطوة 3 من 3</p>
          </div>
          <div className="w-12"></div>
        </div>

        <div className="space-y-6">
          {/* Accommodation */}
          <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">نوع الإقامة</h3>
            <div className="grid grid-cols-2 gap-3">
              {accommodationTypes.map((type) => (
                <Button
                  key={type.id}
                  onClick={() => setTripData((prev) => ({ ...prev, accommodation: type.name }))}
                  className={`p-4 rounded-xl transition-all duration-300 ${
                    tripData.accommodation === type.name
                      ? "bg-gradient-to-r from-orange-500 to-red-500 text-white"
                      : "bg-white/20 dark:bg-white/10 hover:bg-white/30 text-gray-700 dark:text-gray-200"
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <span className="text-xl">{type.icon}</span>
                    <span className="text-sm font-medium">{type.name}</span>
                  </div>
                </Button>
              ))}
            </div>
          </Card>

          {/* Transport */}
          <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">وسيلة النقل</h3>
            <div className="grid grid-cols-2 gap-3">
              {transportTypes.map((type) => (
                <Button
                  key={type.id}
                  onClick={() => setTripData((prev) => ({ ...prev, transport: type.name }))}
                  className={`p-4 rounded-xl transition-all duration-300 ${
                    tripData.transport === type.name
                      ? "bg-gradient-to-r from-blue-500 to-purple-500 text-white"
                      : "bg-white/20 dark:bg-white/10 hover:bg-white/30 text-gray-700 dark:text-gray-200"
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <span className="text-xl">{type.icon}</span>
                    <span className="text-sm font-medium">{type.name}</span>
                  </div>
                </Button>
              ))}
            </div>
          </Card>

          {/* Travel Style */}
          <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">نمط السفر</h3>
            <div className="grid grid-cols-2 gap-3">
              {travelStyles.map((style) => (
                <Button
                  key={style.id}
                  onClick={() => setTripData((prev) => ({ ...prev, travelStyle: style.name }))}
                  className={`p-4 rounded-xl transition-all duration-300 ${
                    tripData.travelStyle === style.name
                      ? "bg-gradient-to-r from-green-500 to-teal-500 text-white"
                      : "bg-white/20 dark:bg-white/10 hover:bg-white/30 text-gray-700 dark:text-gray-200"
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <span className="text-xl">{style.icon}</span>
                    <span className="text-sm font-medium">{style.name}</span>
                  </div>
                </Button>
              ))}
            </div>
          </Card>

          <Button
            onClick={generateTrip}
            disabled={!tripData.accommodation || !tripData.transport || !tripData.travelStyle || isGenerating}
            className="w-full h-16 bg-gradient-to-r from-orange-500 via-red-500 to-pink-500 hover:from-orange-600 hover:via-red-600 hover:to-pink-600 disabled:opacity-50 text-white rounded-2xl shadow-lg"
          >
            {isGenerating ? (
              <div className="flex items-center space-x-3">
                <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                <span className="text-lg font-bold">الذكي الاصطناعي ينشئ خطتك المثالية...</span>
              </div>
            ) : (
              <div className="flex items-center space-x-3">
                <Sparkles className="w-6 h-6" />
                <span className="text-lg font-bold">إنشاء خطة الرحلة الذكية</span>
              </div>
            )}
          </Button>
        </div>
      </div>
    )
  }

  // Step 4: Generated Plan
  if (step === 4) {
    return (
      <div className="p-6 space-y-6 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-gray-900 dark:to-green-900 min-h-screen">
        <div className="flex items-center justify-between">
          <Button
            onClick={() => setStep(3)}
            className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
          >
            <ArrowLeft className="w-6 h-6 text-gray-700 dark:text-gray-200" />
          </Button>
          <div className="text-center">
            <h1 className="text-xl font-bold text-gray-800 dark:text-white">خطة رحلتك المثالية</h1>
            <p className="text-sm text-gray-600 dark:text-gray-300">
              {tripData.destination} • {tripData.dates.start} - {tripData.dates.end}
            </p>
          </div>
          <div className="flex space-x-2">
            <Button onClick={savePlan} className="bg-blue-500 hover:bg-blue-600 text-white rounded-full p-3">
              <Save className="w-5 h-5" />
            </Button>
            <Button onClick={sharePlan} className="bg-green-500 hover:bg-green-600 text-white rounded-full p-3">
              <Share2 className="w-5 h-5" />
            </Button>
            <Button onClick={exportPlan} className="bg-purple-500 hover:bg-purple-600 text-white rounded-full p-3">
              <Download className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Trip Plan */}
        <div className="space-y-4">
          {generatedPlan.map((day) => (
            <Card
              key={day.day}
              className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-lg font-bold text-gray-800 dark:text-white">اليوم {day.day}</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    {day.date} • {day.weather}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-600 dark:text-gray-300">التكلفة اليومية</p>
                  <p className="text-xl font-bold text-green-600">{day.totalCost}</p>
                </div>
              </div>

              <div className="space-y-3">
                {day.activities.map((activity, index) => (
                  <div key={index} className="bg-white/10 rounded-xl p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <Clock className="w-4 h-4 text-blue-600" />
                          <span className="text-sm font-medium text-blue-600">{activity.time}</span>
                          <span className="text-xs bg-gray-200 dark:bg-gray-700 px-2 py-1 rounded-full">
                            {activity.category}
                          </span>
                        </div>
                        <h4 className="font-bold text-gray-800 dark:text-white">{activity.activity}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-300 flex items-center">
                          <MapPin className="w-3 h-3 mr-1" />
                          {activity.location}
                        </p>
                        <div className="flex items-center space-x-2 mt-1">
                          <div className="flex items-center">
                            {[...Array(5)].map((_, i) => (
                              <span
                                key={i}
                                className={`text-xs ${i < Math.floor(activity.rating) ? "text-yellow-400" : "text-gray-300"}`}
                              >
                                ★
                              </span>
                            ))}
                            <span className="text-xs text-gray-500 ml-1">{activity.rating}</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-500">{activity.duration}</p>
                        <p className="font-bold text-green-600">{activity.cost}</p>
                        <Button
                          onClick={() =>
                            window.open(
                              `https://maps.google.com/?q=${activity.coordinates.lat},${activity.coordinates.lng}`,
                              "_blank",
                            )
                          }
                          className="mt-1 bg-blue-500 hover:bg-blue-600 text-white text-xs px-2 py-1 rounded"
                        >
                          خريطة
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          ))}
        </div>

        {/* Total Summary */}
        <Card className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 backdrop-blur-md border border-white/30 rounded-2xl p-6">
          <div className="text-center">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">ملخص الرحلة</h3>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-300">المدة</p>
                <p className="text-xl font-bold text-green-600">{generatedPlan.length} أيام</p>
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-300">التكلفة الإجمالية</p>
                <p className="text-xl font-bold text-green-600">
                  {generatedPlan
                    .reduce(
                      (total, day) => total + Number.parseInt(day.totalCost.replace(/,/g, "").replace(" دج", "")),
                      0,
                    )
                    .toLocaleString()}{" "}
                  دج
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-300">الأنشطة</p>
                <p className="text-xl font-bold text-green-600">
                  {generatedPlan.reduce((total, day) => total + day.activities.length, 0)}
                </p>
              </div>
            </div>
          </div>
        </Card>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-4">
          <Button
            onClick={() => setStep(1)}
            className="bg-white/20 dark:bg-white/10 hover:bg-white/30 text-gray-700 dark:text-gray-200 rounded-2xl p-4"
          >
            إنشاء خطة جديدة
          </Button>
          <Button
            onClick={() => alert("سيتم إضافة ميزة الحجز قريباً!")}
            className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white rounded-2xl p-4"
          >
            احجز الآن
          </Button>
        </div>
      </div>
    )
  }

  return null
}
