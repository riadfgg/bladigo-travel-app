"use client"

import { Search } from "lucide-react"
import { useLanguage } from "@/components/language-provider"

interface FixedSearchBarProps {
  searchQuery: string
  setSearchQuery: (query: string) => void
}

export function FixedSearchBar({ searchQuery, setSearchQuery }: FixedSearchBarProps) {
  const { t } = useLanguage()

  return (
    <div className="fixed top-16 left-0 right-0 z-40 bg-gradient-to-r from-blue-600 to-purple-600 px-4 pb-3">
      <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-xl px-4 py-3">
        <div className="flex items-center space-x-3">
          <Search className="w-5 h-5 text-white/70" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t("common.search")}
            className="flex-1 bg-transparent placeholder-white/60 text-white text-sm outline-none"
          />
        </div>
      </div>
    </div>
  )
}
