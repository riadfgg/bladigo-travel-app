"use client"

import { useState, useEffect } from "react"
import { MapPin, Navigation, Clock, Star, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { useLocation } from "@/components/location-provider"

interface GoogleMapsIntegrationProps {
  onClose: () => void
}

interface NearbyPlace {
  id: string
  name: string
  type: string
  distance: string
  rating: number
  image: string
  coordinates: { lat: number; lng: number }
  estimatedTime: string
  isOpen: boolean
}

export function GoogleMapsIntegration({ onClose }: GoogleMapsIntegrationProps) {
  const { location } = useLocation()
  const [nearbyPlaces, setNearbyPlaces] = useState<NearbyPlace[]>([])
  const [selectedPlace, setSelectedPlace] = useState<NearbyPlace | null>(null)
  const [mapLoaded, setMapLoaded] = useState(false)

  useEffect(() => {
    // Simulate loading nearby places
    if (location) {
      const mockPlaces: NearbyPlace[] = [
        {
          id: "1",
          name: "مقام الشهيد",
          type: "معلم تاريخي",
          distance: "2.3 كم",
          rating: 4.8,
          image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=300&h=200&fit=crop",
          coordinates: { lat: 36.7538, lng: 3.0588 },
          estimatedTime: "15 دقيقة سيراً",
          isOpen: true,
        },
        {
          id: "2",
          name: "فندق الأوراسي",
          type: "فندق",
          distance: "1.2 كم",
          rating: 4.6,
          image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=300&h=200&fit=crop",
          coordinates: { lat: 36.7528, lng: 3.0598 },
          estimatedTime: "8 دقائق سيراً",
          isOpen: true,
        },
        {
          id: "3",
          name: "القصبة العتيقة",
          type: "موقع تراثي",
          distance: "1.8 كم",
          rating: 4.7,
          image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=300&h=200&fit=crop",
          coordinates: { lat: 36.7833, lng: 3.0667 },
          estimatedTime: "12 دقيقة سيراً",
          isOpen: true,
        },
      ]
      setNearbyPlaces(mockPlaces)
    }
  }, [location])

  const openGoogleMaps = (place: NearbyPlace) => {
    const url = `https://www.google.com/maps/dir/${location?.latitude},${location?.longitude}/${place.coordinates.lat},${place.coordinates.lng}`
    window.open(url, "_blank")
  }

  const openGoogleMapsSearch = (query: string) => {
    const url = `https://www.google.com/maps/search/${encodeURIComponent(query)}/@${location?.latitude},${location?.longitude},15z`
    window.open(url, "_blank")
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl h-[80vh] bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl border border-white/30 rounded-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-white/20">
          <div className="flex items-center space-x-3">
            <MapPin className="w-6 h-6 text-blue-600" />
            <h2 className="text-xl font-bold text-gray-800 dark:text-white">الخريطة والأماكن القريبة</h2>
          </div>
          <Button onClick={onClose} className="bg-white/20 hover:bg-white/30 rounded-full p-2">
            <X className="w-5 h-5" />
          </Button>
        </div>

        <div className="flex h-full">
          {/* Map Area */}
          <div className="flex-1 relative">
            <div className="w-full h-full bg-gradient-to-br from-blue-100 to-green-100 dark:from-blue-900 dark:to-green-900 flex items-center justify-center">
              <div className="text-center">
                <MapPin className="w-16 h-16 text-blue-600 mx-auto mb-4" />
                <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-2">خريطة تفاعلية</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-4">موقعك الحالي والأماكن القريبة</p>
                <Button
                  onClick={() => openGoogleMapsSearch("tourist attractions algeria")}
                  className="bg-blue-600 hover:bg-blue-700 text-white rounded-xl px-6 py-3"
                >
                  فتح في خرائط جوجل
                </Button>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="w-80 bg-white/50 dark:bg-gray-800/50 backdrop-blur-md border-l border-white/20 overflow-y-auto">
            <div className="p-4">
              <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">الأماكن القريبة</h3>

              {location ? (
                <div className="mb-4 p-3 bg-green-100 dark:bg-green-900/30 rounded-xl">
                  <div className="flex items-center space-x-2">
                    <Navigation className="w-4 h-4 text-green-600" />
                    <span className="text-sm text-green-800 dark:text-green-200">
                      موقعك: {location.latitude.toFixed(4)}, {location.longitude.toFixed(4)}
                    </span>
                  </div>
                </div>
              ) : (
                <div className="mb-4 p-3 bg-yellow-100 dark:bg-yellow-900/30 rounded-xl">
                  <p className="text-sm text-yellow-800 dark:text-yellow-200">
                    يرجى تفعيل الموقع لرؤية الأماكن القريبة
                  </p>
                </div>
              )}

              <div className="space-y-3">
                {nearbyPlaces.map((place) => (
                  <Card
                    key={place.id}
                    className="bg-white/70 dark:bg-gray-700/70 backdrop-blur-sm border border-white/30 rounded-xl overflow-hidden cursor-pointer hover:bg-white/90 transition-all duration-300"
                    onClick={() => setSelectedPlace(place)}
                  >
                    <div className="relative">
                      <img
                        src={place.image || "/placeholder.svg"}
                        alt={place.name}
                        className="w-full h-32 object-cover"
                      />
                      <div className="absolute top-2 right-2 bg-black/50 backdrop-blur-sm rounded-full px-2 py-1">
                        <div className="flex items-center space-x-1">
                          <Star className="w-3 h-3 text-yellow-400 fill-current" />
                          <span className="text-white text-xs">{place.rating}</span>
                        </div>
                      </div>
                      <div
                        className={`absolute top-2 left-2 px-2 py-1 rounded-full text-xs font-medium ${
                          place.isOpen ? "bg-green-500 text-white" : "bg-red-500 text-white"
                        }`}
                      >
                        {place.isOpen ? "مفتوح" : "مغلق"}
                      </div>
                    </div>

                    <div className="p-3">
                      <h4 className="font-bold text-gray-800 dark:text-white text-sm">{place.name}</h4>
                      <p className="text-xs text-gray-600 dark:text-gray-300 mb-2">{place.type}</p>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-1 text-blue-600">
                          <MapPin className="w-3 h-3" />
                          <span className="text-xs">{place.distance}</span>
                        </div>
                        <div className="flex items-center space-x-1 text-green-600">
                          <Clock className="w-3 h-3" />
                          <span className="text-xs">{place.estimatedTime}</span>
                        </div>
                      </div>

                      <Button
                        onClick={(e) => {
                          e.stopPropagation()
                          openGoogleMaps(place)
                        }}
                        className="w-full mt-2 bg-blue-600 hover:bg-blue-700 text-white text-xs py-2 rounded-lg"
                      >
                        <Navigation className="w-3 h-3 mr-1" />
                        اتجاهات
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>

              {/* Quick Actions */}
              <div className="mt-6 space-y-2">
                <Button
                  onClick={() => openGoogleMapsSearch("restaurants near me algeria")}
                  className="w-full bg-orange-500 hover:bg-orange-600 text-white rounded-xl py-3"
                >
                  🍽️ مطاعم قريبة
                </Button>
                <Button
                  onClick={() => openGoogleMapsSearch("gas stations near me algeria")}
                  className="w-full bg-red-500 hover:bg-red-600 text-white rounded-xl py-3"
                >
                  ⛽ محطات وقود
                </Button>
                <Button
                  onClick={() => openGoogleMapsSearch("hospitals near me algeria")}
                  className="w-full bg-green-500 hover:bg-green-600 text-white rounded-xl py-3"
                >
                  🏥 مستشفيات
                </Button>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  )
}
