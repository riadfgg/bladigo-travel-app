"use client"

import { useState, useEffect } from "react"
import { MapPin, Hotel, Settings, User, MessageCircle, Calendar, Play, Bell } from "lucide-react"
import { Button } from "@/components/ui/button"

interface HomeScreenProps {
  onNavigate: (screen: string) => void
}

export function HomeScreen({ onNavigate }: HomeScreenProps) {
  const [currentAnnouncement, setCurrentAnnouncement] = useState(0)

  const announcements = [
    "🍲 Try El Fenna Cuisine - Traditional Algerian Flavors",
    "🏛️ Explore Timgad Ruins - UNESCO World Heritage",
    "🌅 Sunset at Fort Santa Cruz - Breathtaking Views",
    "🎭 Algiers Festival - Cultural Experience Awaits",
  ]

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentAnnouncement((prev) => (prev + 1) % announcements.length)
    }, 4000)
    return () => clearInterval(timer)
  }, [])

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background with glassmorphism */}
      <div className="absolute inset-0 bg-gradient-to-br from-amber-100/80 via-blue-100/80 to-emerald-100/80 dark:from-gray-900/80 dark:via-blue-900/80 dark:to-emerald-900/80"></div>

      {/* Floating background elements */}
      <div className="absolute top-20 left-10 w-32 h-32 bg-amber-300/20 rounded-full blur-xl animate-float"></div>
      <div className="absolute bottom-40 right-10 w-40 h-40 bg-blue-300/20 rounded-full blur-xl animate-float-delayed"></div>
      <div className="absolute top-1/3 right-20 w-24 h-24 bg-emerald-300/20 rounded-full blur-xl animate-float"></div>

      <div className="relative z-10 p-6 pb-24">
        {/* Header */}
        <div className="flex items-center justify-between mb-8 pt-12">
          <div>
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white">Welcome to</h1>
            <h2 className="text-3xl font-bold bg-gradient-to-r from-amber-600 via-blue-600 to-emerald-600 bg-clip-text text-transparent">
              BladiGo
            </h2>
          </div>
          <Button
            onClick={() => onNavigate("ai-assistant")}
            className="bg-white/20 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
          >
            <MessageCircle className="w-6 h-6 text-blue-600" />
          </Button>
        </div>

        {/* Sliding Announcements */}
        <div className="mb-8 bg-white/20 backdrop-blur-md rounded-2xl border border-white/30 p-4 shadow-lg">
          <div className="flex items-center space-x-2">
            <Bell className="w-5 h-5 text-amber-600 animate-pulse" />
            <p className="text-gray-700 dark:text-gray-200 font-medium transition-all duration-500">
              {announcements[currentAnnouncement]}
            </p>
          </div>
        </div>

        {/* Main Action Buttons */}
        <div className="space-y-6 mb-8">
          <Button
            onClick={() => onNavigate("tourist-spots")}
            className="w-full h-20 bg-gradient-to-r from-amber-500/80 to-orange-500/80 backdrop-blur-md border border-white/30 hover:from-amber-600/80 hover:to-orange-600/80 transition-all duration-300 rounded-2xl shadow-lg hover:shadow-xl transform hover:scale-105"
          >
            <div className="flex items-center space-x-4">
              <MapPin className="w-8 h-8 text-white" />
              <div className="text-left">
                <h3 className="text-xl font-bold text-white">Tourist Spots</h3>
                <p className="text-white/80">Discover amazing places</p>
              </div>
            </div>
          </Button>

          <Button
            onClick={() => onNavigate("hotels")}
            className="w-full h-20 bg-gradient-to-r from-blue-500/80 to-cyan-500/80 backdrop-blur-md border border-white/30 hover:from-blue-600/80 hover:to-cyan-600/80 transition-all duration-300 rounded-2xl shadow-lg hover:shadow-xl transform hover:scale-105"
          >
            <div className="flex items-center space-x-4">
              <Hotel className="w-8 h-8 text-white" />
              <div className="text-left">
                <h3 className="text-xl font-bold text-white">Hotels & Products</h3>
                <p className="text-white/80">Find perfect accommodation</p>
              </div>
            </div>
          </Button>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          <Button
            onClick={() => onNavigate("trip-planner")}
            className="h-16 bg-white/20 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-xl"
          >
            <div className="flex flex-col items-center space-y-1">
              <Calendar className="w-6 h-6 text-emerald-600" />
              <span className="text-sm font-medium text-gray-700 dark:text-gray-200">Trip Planner</span>
            </div>
          </Button>

          <Button
            onClick={() => onNavigate("video-reels")}
            className="h-16 bg-white/20 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-xl"
          >
            <div className="flex flex-col items-center space-y-1">
              <Play className="w-6 h-6 text-red-600" />
              <span className="text-sm font-medium text-gray-700 dark:text-gray-200">Video Reels</span>
            </div>
          </Button>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-6 left-6 right-6 z-20">
        <div className="bg-white/20 backdrop-blur-md rounded-2xl border border-white/30 shadow-lg">
          <div className="flex justify-around py-4">
            <Button
              onClick={() => onNavigate("settings")}
              className="bg-transparent hover:bg-white/20 transition-all duration-300 rounded-xl p-3"
            >
              <Settings className="w-6 h-6 text-gray-600 dark:text-gray-300" />
            </Button>
            <Button
              onClick={() => onNavigate("account")}
              className="bg-transparent hover:bg-white/20 transition-all duration-300 rounded-xl p-3"
            >
              <User className="w-6 h-6 text-gray-600 dark:text-gray-300" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
