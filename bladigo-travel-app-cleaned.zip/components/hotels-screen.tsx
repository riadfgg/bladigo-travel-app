"use client"

import { useState } from "react"
import { ArrowLeft, Star, Wifi, Car, Coffee, MapPin, Heart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface HotelsScreenProps {
  onNavigate: (screen: string) => void
}

const hotels = [
  {
    id: 1,
    name: "Sofitel Algiers Hamma Garden",
    location: "Algiers Center",
    rating: 4.8,
    price: "€120",
    image: "/placeholder.svg?height=200&width=300",
    amenities: ["wifi", "parking", "restaurant"],
    reviews: 1247,
    distance: "0.5 km from Makam El Chahid",
  },
  {
    id: 2,
    name: "Hotel El Aurassi",
    location: "Algiers",
    rating: 4.6,
    price: "€95",
    image: "/placeholder.svg?height=200&width=300",
    amenities: ["wifi", "restaurant", "parking"],
    reviews: 892,
    distance: "1.2 km from Casbah",
  },
  {
    id: 3,
    name: "Sheraton Oran Hotel",
    location: "Oran",
    rating: 4.7,
    price: "€110",
    image: "/placeholder.svg?height=200&width=300",
    amenities: ["wifi", "parking", "restaurant"],
    reviews: 654,
    distance: "2.1 km from Fort Santa Cruz",
  },
  {
    id: 4,
    name: "Timgad Hotel",
    location: "Batna",
    rating: 4.4,
    price: "€75",
    image: "/placeholder.svg?height=200&width=300",
    amenities: ["wifi", "restaurant"],
    reviews: 423,
    distance: "5.0 km from Timgad Ruins",
  },
]

export function HotelsScreen({ onNavigate }: HotelsScreenProps) {
  const [favorites, setFavorites] = useState<number[]>([])

  const toggleFavorite = (hotelId: number) => {
    setFavorites((prev) => (prev.includes(hotelId) ? prev.filter((id) => id !== hotelId) : [...prev, hotelId]))
  }

  const getAmenityIcon = (amenity: string) => {
    switch (amenity) {
      case "wifi":
        return <Wifi className="w-4 h-4" />
      case "parking":
        return <Car className="w-4 h-4" />
      case "restaurant":
        return <Coffee className="w-4 h-4" />
      default:
        return null
    }
  }

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-100/80 via-purple-100/80 to-pink-100/80 dark:from-gray-900/80 dark:via-purple-900/80 dark:to-pink-900/80"></div>

      <div className="relative z-10 p-6 pb-24">
        {/* Header */}
        <div className="flex items-center justify-between mb-6 pt-12">
          <Button
            onClick={() => onNavigate("home")}
            className="bg-white/20 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
          >
            <ArrowLeft className="w-6 h-6 text-gray-700 dark:text-gray-200" />
          </Button>
          <h1 className="text-2xl font-bold text-gray-800 dark:text-white">Hotels & Stay</h1>
          <div className="w-12"></div>
        </div>

        {/* Filter Bar */}
        <div className="mb-6 bg-white/20 backdrop-blur-md rounded-2xl border border-white/30 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-300">Location</p>
              <p className="font-medium text-gray-800 dark:text-white">Algiers, Algeria</p>
            </div>
            <Button className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white rounded-xl px-4 py-2">
              Filter
            </Button>
          </div>
        </div>

        {/* Hotels List */}
        <div className="space-y-4">
          {hotels.map((hotel) => (
            <Card
              key={hotel.id}
              className="bg-white/20 backdrop-blur-md border border-white/30 rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <div className="relative">
                <img src={hotel.image || "/placeholder.svg"} alt={hotel.name} className="w-full h-48 object-cover" />
                <Button
                  onClick={() => toggleFavorite(hotel.id)}
                  className="absolute top-4 right-4 bg-black/50 backdrop-blur-sm hover:bg-black/70 rounded-full p-2"
                >
                  <Heart
                    className={`w-5 h-5 ${favorites.includes(hotel.id) ? "text-red-500 fill-current" : "text-white"}`}
                  />
                </Button>
                <div className="absolute bottom-4 left-4 bg-black/50 backdrop-blur-sm rounded-full px-3 py-1">
                  <div className="flex items-center space-x-1">
                    <Star className="w-4 h-4 text-yellow-400 fill-current" />
                    <span className="text-white text-sm font-medium">{hotel.rating}</span>
                    <span className="text-white/80 text-sm">({hotel.reviews})</span>
                  </div>
                </div>
              </div>

              <div className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-1">{hotel.name}</h3>
                    <div className="flex items-center space-x-1 text-gray-600 dark:text-gray-300 mb-2">
                      <MapPin className="w-4 h-4" />
                      <span className="text-sm">{hotel.location}</span>
                    </div>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{hotel.distance}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-blue-600">{hotel.price}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">per night</p>
                  </div>
                </div>

                {/* Amenities */}
                <div className="flex items-center space-x-3 mb-4">
                  {hotel.amenities.map((amenity, index) => (
                    <div key={index} className="flex items-center space-x-1 text-gray-600 dark:text-gray-300">
                      {getAmenityIcon(amenity)}
                      <span className="text-xs capitalize">{amenity}</span>
                    </div>
                  ))}
                </div>

                <div className="flex space-x-3">
                  <Button className="flex-1 bg-white/20 hover:bg-white/30 text-gray-700 dark:text-gray-200 rounded-xl">
                    View Details
                  </Button>
                  <Button className="flex-1 bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white rounded-xl">
                    Book Now
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
