"use client"

import { useState } from "react"
import {
  ArrowLeft,
  Star,
  MapPin,
  Wifi,
  Car,
  Coffee,
  CreditCard,
  Heart,
  Shield,
  Phone,
  Mail,
  Clock,
  Users,
  Bed,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

// Import language support
import { useLanguage } from "@/components/language-provider"
import { HotelBooking } from "@/components/hotel-booking"

interface Hotel {
  id: number
  name: string
  location: string
  rating: number
  price: string
  originalPrice?: string
  image: string
  amenities: string[]
  reviews: number
  distance: string
  featured: boolean
  commission: number
  availability: "available" | "limited" | "unavailable"
  phone: string
  email: string
  checkIn: string
  checkOut: string
  rooms: number
  description: string
  gallery: string[]
}

interface HotelsSectionProps {
  onBack: () => void
}

export function HotelsSection({ onBack }: HotelsSectionProps) {
  const [favorites, setFavorites] = useState<number[]>([])
  const [selectedHotel, setSelectedHotel] = useState<number | null>(null)
  const [bookingHotel, setBookingHotel] = useState<Hotel | null>(null)

  // Update hotels with detailed information
  const hotels: Hotel[] = [
    {
      id: 1,
      name: "Sofitel Algiers Hamma Garden",
      location: "Algiers Center",
      rating: 4.8,
      price: "18,000",
      originalPrice: "22,500",
      image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400&h=300&fit=crop",
      amenities: ["wifi", "parking", "restaurant", "spa"],
      reviews: 1247,
      distance: "0.5 km from you",
      featured: true,
      commission: 2250,
      availability: "available",
      phone: "+213 21 68 52 10",
      email: "reservations@sofitel-algiers.com",
      checkIn: "15:00",
      checkOut: "12:00",
      rooms: 280,
      description:
        "فندق فاخر من فئة 5 نجوم يقع في قلب الجزائر العاصمة، يوفر إطلالات خلابة على البحر الأبيض المتوسط وحدائق الحامة الجميلة.",
      gallery: [
        "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400&h=300&fit=crop",
        "https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=400&h=300&fit=crop",
        "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=400&h=300&fit=crop",
      ],
    },
    {
      id: 2,
      name: "Hotel El Aurassi",
      location: "Algiers",
      rating: 4.6,
      price: "14,250",
      image: "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=400&h=300&fit=crop",
      amenities: ["wifi", "restaurant", "parking"],
      reviews: 892,
      distance: "1.2 km from you",
      featured: false,
      commission: 1800,
      availability: "limited",
      phone: "+213 21 74 82 52",
      email: "info@elaurassi.dz",
      checkIn: "14:00",
      checkOut: "12:00",
      rooms: 412,
      description: "فندق تاريخي مميز في الجزائر العاصمة، يجمع بين الأصالة والحداثة مع خدمات متميزة وموقع استراتيجي.",
      gallery: [
        "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=400&h=300&fit=crop",
        "https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=400&h=300&fit=crop",
      ],
    },
    {
      id: 3,
      name: "Sheraton Oran Hotel",
      location: "Oran",
      rating: 4.7,
      price: "16,500",
      originalPrice: "19,500",
      image: "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=400&h=300&fit=crop",
      amenities: ["wifi", "parking", "restaurant", "pool"],
      reviews: 654,
      distance: "2.1 km from you",
      featured: true,
      commission: 2700,
      availability: "available",
      phone: "+213 41 59 01 00",
      email: "reservations@sheraton-oran.com",
      checkIn: "15:00",
      checkOut: "11:00",
      rooms: 230,
      description: "فندق عالمي المستوى في وهران، يوفر أجنحة فاخرة ومرافق ترفيهية متكاملة مع إطلالة رائعة على البحر.",
      gallery: [
        "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=400&h=300&fit=crop",
        "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400&h=300&fit=crop",
      ],
    },
    {
      id: 4,
      name: "Marriott Hotel Algiers",
      location: "Algiers",
      rating: 4.5,
      price: "13,500",
      image: "https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=400&h=300&fit=crop",
      amenities: ["wifi", "restaurant", "gym"],
      reviews: 523,
      distance: "3.2 km from you",
      featured: false,
      commission: 1620,
      availability: "available",
      phone: "+213 21 98 98 00",
      email: "algiers@marriott.com",
      checkIn: "15:00",
      checkOut: "12:00",
      rooms: 412,
      description:
        "فندق ماريوت الأنيق في الجزائر العاصمة، يقدم تجربة إقامة استثنائية مع خدمات الضيافة العالمية المعروفة.",
      gallery: [
        "https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=400&h=300&fit=crop",
        "https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=400&h=300&fit=crop",
      ],
    },
    {
      id: 5,
      name: "Hilton Alger",
      location: "Algiers",
      rating: 4.4,
      price: "12,750",
      image: "https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=400&h=300&fit=crop",
      amenities: ["wifi", "parking", "restaurant", "spa", "pool"],
      reviews: 789,
      distance: "2.8 km from you",
      featured: false,
      commission: 1530,
      availability: "limited",
      phone: "+213 21 21 96 96",
      email: "reservations@hilton-algiers.com",
      checkIn: "15:00",
      checkOut: "12:00",
      rooms: 314,
      description: "فندق هيلتون الجزائر يوفر إقامة فاخرة مع مرافق متطورة وخدمات عالية الجودة في موقع مميز بالعاصمة.",
      gallery: [
        "https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=400&h=300&fit=crop",
        "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400&h=300&fit=crop",
      ],
    },
  ]

  // Add language support
  const { t, isRTL } = useLanguage()

  const getAmenityIcon = (amenity: string) => {
    switch (amenity) {
      case "wifi":
        return <Wifi className="w-4 h-4" />
      case "parking":
        return <Car className="w-4 h-4" />
      case "restaurant":
        return <Coffee className="w-4 h-4" />
      case "spa":
        return <span className="text-xs">🧖‍♀️</span>
      case "pool":
        return <span className="text-xs">🏊‍♂️</span>
      default:
        return null
    }
  }

  const toggleFavorite = (hotelId: number) => {
    setFavorites((prev) => (prev.includes(hotelId) ? prev.filter((id) => id !== hotelId) : [...prev, hotelId]))
  }

  const handleBooking = (hotel: Hotel) => {
    setBookingHotel(hotel)
  }

  const handleCall = (phone: string) => {
    window.open(`tel:${phone}`, "_self")
  }

  const handleEmail = (email: string) => {
    window.open(`mailto:${email}`, "_self")
  }

  // Hotel Details View
  if (selectedHotel) {
    const hotel = hotels.find((h) => h.id === selectedHotel)!
    return (
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <Button
            onClick={() => setSelectedHotel(null)}
            className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
          >
            <ArrowLeft className="w-6 h-6 text-gray-700 dark:text-gray-200" />
          </Button>
          <h1 className="text-xl font-bold text-gray-800 dark:text-white">تفاصيل الفندق</h1>
          <Button
            onClick={() => toggleFavorite(hotel.id)}
            className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
          >
            <Heart
              className={`w-6 h-6 ${favorites.includes(hotel.id) ? "text-red-500 fill-current" : "text-gray-700 dark:text-gray-200"}`}
            />
          </Button>
        </div>

        {/* Hotel Images Gallery */}
        <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl overflow-hidden">
          <div className="relative">
            <img src={hotel.image || "/placeholder.svg"} alt={hotel.name} className="w-full h-64 object-cover" />
            <div className="absolute top-4 left-4 bg-emerald-500/80 backdrop-blur-sm rounded-full px-3 py-1">
              <div className="flex items-center space-x-1">
                <Star className="w-4 h-4 text-white fill-current" />
                <span className="text-white text-sm font-medium">{hotel.rating}</span>
              </div>
            </div>
          </div>
          <div className="p-4">
            <div className="flex space-x-2 overflow-x-auto">
              {hotel.gallery.map((img, index) => (
                <img
                  key={index}
                  src={img || "/placeholder.svg"}
                  alt={`${hotel.name} ${index + 1}`}
                  className="w-20 h-20 object-cover rounded-lg flex-shrink-0"
                />
              ))}
            </div>
          </div>
        </Card>

        {/* Hotel Info */}
        <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">{hotel.name}</h2>
              <div className="flex items-center space-x-2 text-gray-600 dark:text-gray-300 mb-2">
                <MapPin className="w-4 h-4" />
                <span>{hotel.location}</span>
              </div>
              <p className="text-emerald-600 text-sm font-medium">{hotel.distance}</p>
            </div>
            <div className="text-right">
              <div className="flex items-center space-x-2 mb-2">
                {hotel.originalPrice && (
                  <span className="text-sm text-gray-500 line-through">{hotel.originalPrice} دج</span>
                )}
                <p className="text-2xl font-bold text-blue-600">{hotel.price} دج</p>
              </div>
              <p className="text-sm text-gray-500">لكل ليلة</p>
            </div>
          </div>

          <p className="text-gray-600 dark:text-gray-300 mb-6">{hotel.description}</p>

          {/* Hotel Details */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4 text-blue-600" />
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-300">تسجيل الوصول</p>
                <p className="font-medium text-gray-800 dark:text-white">{hotel.checkIn}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4 text-red-600" />
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-300">تسجيل المغادرة</p>
                <p className="font-medium text-gray-800 dark:text-white">{hotel.checkOut}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Bed className="w-4 h-4 text-purple-600" />
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-300">عدد الغرف</p>
                <p className="font-medium text-gray-800 dark:text-white">{hotel.rooms}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Users className="w-4 h-4 text-green-600" />
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-300">التقييمات</p>
                <p className="font-medium text-gray-800 dark:text-white">{hotel.reviews}</p>
              </div>
            </div>
          </div>

          {/* Amenities */}
          <div className="mb-6">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-3">المرافق والخدمات</h3>
            <div className="flex items-center space-x-4">
              {hotel.amenities.map((amenity, index) => (
                <div key={index} className="flex items-center space-x-2 bg-white/10 rounded-xl px-3 py-2">
                  {getAmenityIcon(amenity)}
                  <span className="text-sm capitalize text-gray-700 dark:text-gray-200">{amenity}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Contact & Booking */}
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <Button
                onClick={() => handleCall(hotel.phone)}
                className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white rounded-xl"
              >
                <Phone className="w-4 h-4 mr-2" />
                اتصال
              </Button>
              <Button
                onClick={() => handleEmail(hotel.email)}
                className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white rounded-xl"
              >
                <Mail className="w-4 h-4 mr-2" />
                إيميل
              </Button>
            </div>
            <Button
              onClick={() => handleBooking(hotel)}
              disabled={hotel.availability === "unavailable" || bookingHotel === hotel}
              className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 disabled:opacity-50 text-white rounded-xl"
            >
              {bookingHotel === hotel ? (
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>جاري الحجز...</span>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <CreditCard className="w-4 h-4" />
                  <span>احجز الآن - اكسب {hotel.commission} دج</span>
                </div>
              )}
            </Button>
          </div>

          {/* Contact Info */}
          <div className="mt-6 pt-6 border-t border-white/20">
            <div className="grid grid-cols-1 gap-3">
              <div className="flex items-center space-x-3">
                <Phone className="w-4 h-4 text-green-600" />
                <span className="text-gray-700 dark:text-gray-200">{hotel.phone}</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-4 h-4 text-blue-600" />
                <span className="text-gray-700 dark:text-gray-200">{hotel.email}</span>
              </div>
            </div>
          </div>
        </Card>
      </div>
    )
  }

  // Hotel Booking View
  if (bookingHotel) {
    return (
      <HotelBooking
        hotel={bookingHotel}
        onBack={() => setBookingHotel(null)}
        onBookingComplete={(bookingData) => {
          alert(`تم تأكيد الحجز! رقم الحجز: ${bookingData.bookingId}`)
          setBookingHotel(null)
        }}
      />
    )
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <Button
          onClick={onBack}
          className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
        >
          <ArrowLeft className="w-6 h-6 text-gray-700 dark:text-gray-200" />
        </Button>
        <h1 className="text-2xl font-bold text-gray-800 dark:text-white">الفنادق المميزة</h1>
        <div className="w-12"></div>
      </div>

      {/* Maqam Echahid Image */}
      <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl overflow-hidden mb-6">
        <div className="relative">
          <img
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images.jpg-mn9ISgDwvKXL0WDykpIIUfhadb8chk.jpeg"
            alt="مقام الشهيد - الجزائر"
            className="w-full h-48 object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
          <div className="absolute bottom-4 left-4 right-4">
            <h3 className="text-xl font-bold text-white mb-1">مقام الشهيد</h3>
            <p className="text-white/80 text-sm">رمز الاستقلال والكرامة الوطنية</p>
          </div>
        </div>
      </Card>

      {/* Filter Info */}
      <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 backdrop-blur-md border border-white/30 rounded-2xl p-4">
        <p className="text-sm text-gray-700 dark:text-gray-200">
          🔥 <strong>عروض خاصة:</strong> احجز الآن ووفر حتى 20% على الفنادق المميزة
        </p>
      </div>

      {/* Hotels List */}
      <div className="space-y-4">
        {hotels.map((hotel) => (
          <Card
            key={hotel.id}
            className={`backdrop-blur-md border border-white/30 rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer ${
              hotel.featured ? "bg-gradient-to-r from-amber-500/20 to-orange-500/20" : "bg-white/20 dark:bg-white/10"
            }`}
            onClick={() => setSelectedHotel(hotel.id)}
          >
            {hotel.featured && (
              <div className="bg-gradient-to-r from-amber-500 to-orange-500 text-white text-center py-2">
                <span className="text-sm font-bold">⭐ مميز - أفضل عرض</span>
              </div>
            )}

            <div className="relative">
              <img src={hotel.image || "/placeholder.svg"} alt={hotel.name} className="w-full h-48 object-cover" />
              <Button
                onClick={(e) => {
                  e.stopPropagation()
                  toggleFavorite(hotel.id)
                }}
                className="absolute top-4 right-4 bg-black/50 backdrop-blur-sm hover:bg-black/70 rounded-full p-2"
              >
                <Heart
                  className={`w-5 h-5 ${favorites.includes(hotel.id) ? "text-red-500 fill-current" : "text-white"}`}
                />
              </Button>
              <div className="absolute bottom-4 left-4 bg-black/50 backdrop-blur-sm rounded-full px-3 py-1">
                <div className="flex items-center space-x-1">
                  <Star className="w-4 h-4 text-yellow-400 fill-current" />
                  <span className="text-white text-sm font-medium">{hotel.rating}</span>
                  <span className="text-white/80 text-sm">({hotel.reviews})</span>
                </div>
              </div>
              <div
                className={`absolute top-4 left-4 backdrop-blur-sm rounded-full px-3 py-1 ${
                  hotel.availability === "available"
                    ? "bg-green-500/80"
                    : hotel.availability === "limited"
                      ? "bg-yellow-500/80"
                      : "bg-red-500/80"
                }`}
              >
                <span className="text-white text-xs font-medium">
                  {hotel.availability === "available"
                    ? "متاح"
                    : hotel.availability === "limited"
                      ? "باقي القليل"
                      : "نفدت الكمية"}
                </span>
              </div>
            </div>

            <div className="p-4">
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-1">{hotel.name}</h3>
                  <div className="flex items-center space-x-1 text-gray-600 dark:text-gray-300 mb-2">
                    <MapPin className="w-4 h-4" />
                    <span className="text-sm">{hotel.location}</span>
                  </div>
                  <p className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">{hotel.distance}</p>
                </div>
                <div className="text-right">
                  <div className="flex items-center space-x-2">
                    {hotel.originalPrice && (
                      <span className="text-sm text-gray-500 line-through">{hotel.originalPrice} دج</span>
                    )}
                    <p className="text-2xl font-bold text-blue-600">{hotel.price} دج</p>
                  </div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">لكل ليلة</p>
                  {hotel.commission > 0 && <p className="text-xs text-green-600">اكسب {hotel.commission} دج</p>}
                </div>
              </div>

              {/* Amenities */}
              <div className="flex items-center space-x-3 mb-4">
                {hotel.amenities.slice(0, 4).map((amenity, index) => (
                  <div key={index} className="flex items-center space-x-1 text-gray-600 dark:text-gray-300">
                    {getAmenityIcon(amenity)}
                    <span className="text-xs capitalize">{amenity}</span>
                  </div>
                ))}
              </div>

              <div className="flex space-x-3">
                <Button
                  onClick={(e) => {
                    e.stopPropagation()
                    setSelectedHotel(hotel.id)
                  }}
                  className="flex-1 bg-white/20 dark:bg-white/10 hover:bg-white/30 text-gray-700 dark:text-gray-200 rounded-xl"
                >
                  عرض التفاصيل
                </Button>
                <Button
                  onClick={(e) => {
                    e.stopPropagation()
                    handleBooking(hotel)
                  }}
                  disabled={hotel.availability === "unavailable" || bookingHotel === hotel}
                  className="flex-1 bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 disabled:opacity-50 text-white rounded-xl"
                >
                  {bookingHotel === hotel ? (
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>جاري الحجز...</span>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-2">
                      <CreditCard className="w-4 h-4" />
                      <span>احجز الآن</span>
                    </div>
                  )}
                </Button>
              </div>

              {/* Security Badge */}
              <div className="flex items-center justify-center mt-3 text-xs text-gray-500 dark:text-gray-400">
                <Shield className="w-3 h-3 mr-1" />
                <span>حجز آمن • إلغاء مجاني</span>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
