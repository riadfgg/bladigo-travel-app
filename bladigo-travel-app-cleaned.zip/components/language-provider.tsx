"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

interface Translations {
  [key: string]: {
    [key: string]: string
  }
}

const translations: Translations = {
  ar: {
    // App Name & Slogan
    "app.name": "بلادي غو",
    "app.slogan": "اكتشف جمال الجزائر",
    "app.subtitle": "تجربة سفر عالمية المستوى",

    // Navigation
    "nav.home": "الرئيسية",
    "nav.tourist_spots": "الأماكن السياحية",
    "nav.hotels": "الفنادق والمنتجات",
    "nav.account": "الحساب",
    "nav.settings": "الإعدادات",
    "nav.ai_assistant": "المساعد الذكي",
    "nav.trip_planner": "مخطط الرحلات",

    // Home Screen
    "home.welcome": "مرحباً بكم في الجزائر",
    "home.subtitle": "اكتشف وجهات خلابة مع توصيات مدعومة بالذكاء الاصطناعي",
    "home.discover_places": "🗺️ اكتشف الأماكن",
    "home.discover_subtitle": "استكشف وجهات مذهلة",
    "home.find_hotels": "🏨 ابحث عن الفنادق",
    "home.find_hotels_subtitle": "احجز أماكن إقامة مثالية",
    "home.destinations": "وجهة",
    "home.hotels": "فندق",
    "home.rating": "تقييم",

    // Tourist Spots
    "spots.title": "الوجهات السياحية",
    "spots.back": "رجوع",
    "spots.view_map": "عرض على الخريطة",
    "spots.gallery": "المعرض",
    "spots.get_directions": "الحصول على الاتجاهات",
    "spots.beauty": "الجمال",
    "spots.access": "الوصول",
    "spots.clean": "النظافة",
    "spots.ai_suggestions": "🤖 قد يعجبك أيضاً...",

    // Hotels
    "hotels.title": "الفنادق المميزة",
    "hotels.featured": "⭐ مميز - أفضل عرض",
    "hotels.per_night": "لكل ليلة",
    "hotels.earn": "اكسب",
    "hotels.view_details": "عرض التفاصيل",
    "hotels.book_now": "احجز الآن",
    "hotels.booking": "جاري الحجز...",
    "hotels.available": "متاح",
    "hotels.limited": "باقي القليل",
    "hotels.sold_out": "نفدت الكمية",
    "hotels.secure_booking": "حجز آمن • إلغاء مجاني",

    // AI Assistant
    "ai.title": "المساعد الذكي",
    "ai.subtitle": "رفيقك الذكي في السفر",
    "ai.thinking": "الذكاء الاصطناعي يفكر...",
    "ai.placeholder": "اسألني أي شيء عن الجزائر...",
    "ai.quick_questions": "أسئلة سريعة للبدء:",
    "ai.best_places": "أفضل الأماكن للزيارة في الجزائر",
    "ai.food_recommendations": "توصيات الطعام الجزائري التقليدي",
    "ai.hotels_algiers": "فنادق في الجزائر العاصمة",
    "ai.plan_trip": "خطط رحلة لمدة 3 أيام",
    "ai.weather": "الطقس في الجزائر",
    "ai.cultural_attractions": "المعالم الثقافية",

    // Trip Planner
    "trip.title": "مخطط الرحلات بالذكاء الاصطناعي",
    "trip.step": "الخطوة",
    "trip.destination": "الوجهة",
    "trip.duration": "المدة",
    "trip.travelers": "المسافرون",
    "trip.budget": "الميزانية",
    "trip.interests": "ما الذي يثير اهتمامك أكثر؟",
    "trip.travel_dates": "تواريخ السفر (اختياري)",
    "trip.generate": "إنشاء رحلتي المثالية",
    "trip.generating": "الذكاء الاصطناعي ينشئ رحلتك المثالية...",
    "trip.perfect_trip": "رحلتك المثالية",
    "trip.summary": "ملخص الرحلة",
    "trip.total_duration": "المدة الإجمالية",
    "trip.estimated_cost": "التكلفة المقدرة",
    "trip.days": "أيام",

    // Settings
    "settings.title": "الإعدادات",
    "settings.language": "اللغة",
    "settings.theme": "المظهر",
    "settings.light": "فاتح",
    "settings.dark": "داكن",
    "settings.system": "النظام",
    "settings.notifications": "الإشعارات",
    "settings.push_notifications": "الإشعارات المنبثقة",
    "settings.push_subtitle": "إشعارات التطبيق العامة",
    "settings.geo_alerts": "التنبيهات الجغرافية",
    "settings.geo_subtitle": "تنبيهات السفر المبنية على الموقع",
    "settings.ai_assistant": "المساعد الذكي",
    "settings.enable_ai": "تفعيل المساعد الذكي",
    "settings.ai_subtitle": "توصيات السفر الذكية",
    "settings.cultural_first": "الأماكن الثقافية أولاً",
    "settings.cultural_subtitle": "إعطاء الأولوية للمعالم الثقافية",
    "settings.privacy": "الخصوصية والأمان",
    "settings.privacy_subtitle": "إدارة بياناتك وخصوصيتك",
    "settings.help": "المساعدة والدعم",
    "settings.help_subtitle": "الحصول على المساعدة والتواصل مع الدعم",
    "settings.clear_trips": "مسح الرحلات المحفوظة",
    "settings.clear_subtitle": "إزالة جميع بيانات الرحلات المحفوظة",
    "settings.version": "الإصدار 1.0.0",
    "settings.premium": "تجربة السياحة الجزائرية المميزة",

    // Account
    "account.title": "حسابي",
    "account.explorer": "مستكشف",
    "account.traveler_since": "مسافر منذ",
    "account.trips": "رحلات",
    "account.favorites": "المفضلة",
    "account.reviews": "المراجعات",
    "account.achievements": "الإنجازات",
    "account.recent_trips": "الرحلات الأخيرة",
    "account.my_favorites": "مفضلاتي",
    "account.trip_history": "تاريخ الرحلات",
    "account.sign_out": "تسجيل الخروج",

    // Common
    "common.back": "رجوع",
    "common.search": "البحث عن الوجهات والفنادق والتجارب...",
    "common.loading": "جاري التحميل...",
    "common.error": "حدث خطأ",
    "common.retry": "إعادة المحاولة",
    "common.close": "إغلاق",
    "common.save": "حفظ",
    "common.cancel": "إلغاء",
    "common.continue": "متابعة",
    "common.done": "تم",

    // Locations
    "location.algiers": "الجزائر العاصمة",
    "location.oran": "وهران",
    "location.constantine": "قسنطينة",
    "location.batna": "باتنة",
    "location.tlemcen": "تلمسان",
    "location.ghardaia": "غرداية",
    "location.tamanrasset": "تمنراست",

    // Currencies
    "currency.dzd": "د.ج",
    "currency.per_night": "لكل ليلة",
  },
  en: {
    // App Name & Slogan
    "app.name": "BladiGo",
    "app.slogan": "Discover Algeria's Beauty",
    "app.subtitle": "World-class travel experience",

    // Navigation
    "nav.home": "Home",
    "nav.tourist_spots": "Tourist Spots",
    "nav.hotels": "Hotels & Products",
    "nav.account": "Account",
    "nav.settings": "Settings",
    "nav.ai_assistant": "AI Assistant",
    "nav.trip_planner": "Trip Planner",

    // Home Screen
    "home.welcome": "Welcome to Algeria",
    "home.subtitle": "Discover breathtaking destinations with AI-powered recommendations",
    "home.discover_places": "🗺️ Discover Places",
    "home.discover_subtitle": "Explore amazing destinations",
    "home.find_hotels": "🏨 Find Hotels",
    "home.find_hotels_subtitle": "Book perfect accommodations",
    "home.destinations": "Destinations",
    "home.hotels": "Hotels",
    "home.rating": "Rating",

    // Tourist Spots
    "spots.title": "Tourist Destinations",
    "spots.back": "Back",
    "spots.view_map": "View on Map",
    "spots.gallery": "Gallery",
    "spots.get_directions": "Get Directions",
    "spots.beauty": "Beauty",
    "spots.access": "Access",
    "spots.clean": "Clean",
    "spots.ai_suggestions": "🤖 You may also like...",

    // Hotels
    "hotels.title": "Premium Hotels",
    "hotels.featured": "⭐ FEATURED - Best Deal",
    "hotels.per_night": "per night",
    "hotels.earn": "Earn",
    "hotels.view_details": "View Details",
    "hotels.book_now": "Book Now",
    "hotels.booking": "Booking...",
    "hotels.available": "Available",
    "hotels.limited": "Few Left",
    "hotels.sold_out": "Sold Out",
    "hotels.secure_booking": "Secure booking • Free cancellation",

    // AI Assistant
    "ai.title": "AI Assistant",
    "ai.subtitle": "Your intelligent travel companion",
    "ai.thinking": "AI is thinking...",
    "ai.placeholder": "Ask me anything about Algeria...",
    "ai.quick_questions": "Quick questions to get started:",
    "ai.best_places": "Best places to visit in Algeria",
    "ai.food_recommendations": "Traditional Algerian food recommendations",
    "ai.hotels_algiers": "Hotels in Algiers",
    "ai.plan_trip": "Plan a 3-day trip",
    "ai.weather": "Weather in Algeria",
    "ai.cultural_attractions": "Cultural attractions",

    // Trip Planner
    "trip.title": "AI Trip Planner",
    "trip.step": "Step",
    "trip.destination": "Destination",
    "trip.duration": "Duration",
    "trip.travelers": "Travelers",
    "trip.budget": "Budget",
    "trip.interests": "What interests you most?",
    "trip.travel_dates": "Travel Dates (Optional)",
    "trip.generate": "Generate My Perfect Trip",
    "trip.generating": "AI is creating your perfect trip...",
    "trip.perfect_trip": "Your Perfect Trip",
    "trip.summary": "Trip Summary",
    "trip.total_duration": "Total Duration",
    "trip.estimated_cost": "Estimated Cost",
    "trip.days": "Days",

    // Settings
    "settings.title": "Settings",
    "settings.language": "Language",
    "settings.theme": "Theme",
    "settings.light": "Light",
    "settings.dark": "Dark",
    "settings.system": "System",
    "settings.notifications": "Notifications",
    "settings.push_notifications": "Push Notifications",
    "settings.push_subtitle": "General app notifications",
    "settings.geo_alerts": "Geo-based Alerts",
    "settings.geo_subtitle": "Location-based travel alerts",
    "settings.ai_assistant": "AI Assistant",
    "settings.enable_ai": "Enable AI Assistant",
    "settings.ai_subtitle": "Smart travel recommendations",
    "settings.cultural_first": "Cultural Places First",
    "settings.cultural_subtitle": "Prioritize cultural attractions",
    "settings.privacy": "Privacy & Security",
    "settings.privacy_subtitle": "Manage your data and privacy",
    "settings.help": "Help & Support",
    "settings.help_subtitle": "Get help and contact support",
    "settings.clear_trips": "Clear Saved Trips",
    "settings.clear_subtitle": "Remove all saved trip data",
    "settings.version": "Version 1.0.0",
    "settings.premium": "Premium Algeria Tourism Experience",

    // Account
    "account.title": "My Account",
    "account.explorer": "Explorer",
    "account.traveler_since": "Traveler since",
    "account.trips": "Trips",
    "account.favorites": "Favorites",
    "account.reviews": "Reviews",
    "account.achievements": "Achievements",
    "account.recent_trips": "Recent Trips",
    "account.my_favorites": "My Favorites",
    "account.trip_history": "Trip History",
    "account.sign_out": "Sign Out",

    // Common
    "common.back": "Back",
    "common.search": "Search destinations, hotels, experiences...",
    "common.loading": "Loading...",
    "common.error": "An error occurred",
    "common.retry": "Retry",
    "common.close": "Close",
    "common.save": "Save",
    "common.cancel": "Cancel",
    "common.continue": "Continue",
    "common.done": "Done",

    // Locations
    "location.algiers": "Algiers",
    "location.oran": "Oran",
    "location.constantine": "Constantine",
    "location.batna": "Batna",
    "location.tlemcen": "Tlemcen",
    "location.ghardaia": "Ghardaia",
    "location.tamanrasset": "Tamanrasset",

    // Currencies
    "currency.dzd": "DZD",
    "currency.per_night": "per night",
  },
  fr: {
    // App Name & Slogan
    "app.name": "BladiGo",
    "app.slogan": "Découvrez la beauté de l'Algérie",
    "app.subtitle": "Expérience de voyage de classe mondiale",

    // Navigation
    "nav.home": "Accueil",
    "nav.tourist_spots": "Sites touristiques",
    "nav.hotels": "Hôtels et produits",
    "nav.account": "Compte",
    "nav.settings": "Paramètres",
    "nav.ai_assistant": "Assistant IA",
    "nav.trip_planner": "Planificateur de voyage",

    // Common
    "common.back": "Retour",
    "common.search": "Rechercher destinations, hôtels, expériences...",
    "common.loading": "Chargement...",

    // Currencies
    "currency.dzd": "DA",
    "currency.per_night": "par nuit",
  },
}

interface LanguageContextType {
  language: string
  setLanguage: (lang: string) => void
  t: (key: string) => string
  isRTL: boolean
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState("ar")

  useEffect(() => {
    const savedLanguage = localStorage.getItem("bladigo-language")
    if (savedLanguage && translations[savedLanguage]) {
      setLanguage(savedLanguage)
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("bladigo-language", language)
    document.documentElement.lang = language
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr"
  }, [language])

  const t = (key: string): string => {
    return translations[language]?.[key] || translations["en"]?.[key] || key
  }

  const isRTL = language === "ar"

  return <LanguageContext.Provider value={{ language, setLanguage, t, isRTL }}>{children}</LanguageContext.Provider>
}

export const useLanguage = () => {
  const context = useContext(LanguageContext)
  if (!context) {
    throw new Error("useLanguage must be used within LanguageProvider")
  }
  return context
}
