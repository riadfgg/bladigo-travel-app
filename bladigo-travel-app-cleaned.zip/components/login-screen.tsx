"use client"

import type React from "react"

import { useState } from "react"
import { Eye, EyeOff, Mail, Lock, User, Phone } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface LoginScreenProps {
  onLogin: (userData: any) => void
}

export function LoginScreen({ onLogin }: LoginScreenProps) {
  const [isLogin, setIsLogin] = useState(true)
  const [showPassword, setShowPassword] = useState(false)
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    name: "",
    phone: "",
    confirmPassword: "",
  })
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))

    if (isLogin) {
      // Login logic
      onLogin({
        name: "أحمد بن علي",
        email: formData.email,
        phone: "+213 555 123 456",
        avatar: "/placeholder.svg?height=120&width=120&text=AB",
      })
    } else {
      // Register logic
      onLogin({
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        avatar: "/placeholder.svg?height=120&width=120&text=" + formData.name.charAt(0),
      })
    }

    setIsLoading(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-100 via-blue-100 to-emerald-100 dark:from-gray-900 dark:via-blue-900 dark:to-emerald-900 flex items-center justify-center p-6">
      {/* Background Elements */}
      <div className="absolute top-20 left-10 w-32 h-32 bg-amber-300/20 rounded-full blur-xl animate-float"></div>
      <div className="absolute bottom-20 right-10 w-40 h-40 bg-blue-300/20 rounded-full blur-xl animate-float-delayed"></div>

      <Card className="w-full max-w-md bg-white/20 dark:bg-white/10 backdrop-blur-xl border border-white/30 rounded-3xl p-8 shadow-2xl">
        {/* Logo */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-amber-600 via-blue-600 to-emerald-600 bg-clip-text text-transparent">
            BladiGo
          </h1>
          <p className="text-gray-600 dark:text-gray-300 mt-2">{isLogin ? "مرحباً بعودتك!" : "انضم إلينا اليوم"}</p>
        </div>

        {/* Toggle Buttons */}
        <div className="flex bg-white/10 rounded-2xl p-1 mb-6">
          <Button
            onClick={() => setIsLogin(true)}
            className={`flex-1 py-3 rounded-xl transition-all duration-300 ${
              isLogin
                ? "bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-lg"
                : "bg-transparent text-gray-600 dark:text-gray-300"
            }`}
          >
            تسجيل الدخول
          </Button>
          <Button
            onClick={() => setIsLogin(false)}
            className={`flex-1 py-3 rounded-xl transition-all duration-300 ${
              !isLogin
                ? "bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-lg"
                : "bg-transparent text-gray-600 dark:text-gray-300"
            }`}
          >
            إنشاء حساب
          </Button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <>
              <div className="relative">
                <User className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="الاسم الكامل"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-white/10 border border-white/20 rounded-xl px-12 py-4 text-gray-800 dark:text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-300"
                  required={!isLogin}
                />
              </div>

              <div className="relative">
                <Phone className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="tel"
                  placeholder="رقم الهاتف"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-white/10 border border-white/20 rounded-xl px-12 py-4 text-gray-800 dark:text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-300"
                  required={!isLogin}
                />
              </div>
            </>
          )}

          <div className="relative">
            <Mail className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="email"
              placeholder="البريد الإلكتروني"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="w-full bg-white/10 border border-white/20 rounded-xl px-12 py-4 text-gray-800 dark:text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-300"
              required
            />
          </div>

          <div className="relative">
            <Lock className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type={showPassword ? "text" : "password"}
              placeholder="كلمة المرور"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              className="w-full bg-white/10 border border-white/20 rounded-xl px-12 py-4 text-gray-800 dark:text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-300"
              required
            />
            <Button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute left-3 top-1/2 transform -translate-y-1/2 bg-transparent hover:bg-transparent p-0"
            >
              {showPassword ? <EyeOff className="w-5 h-5 text-gray-400" /> : <Eye className="w-5 h-5 text-gray-400" />}
            </Button>
          </div>

          {!isLogin && (
            <div className="relative">
              <Lock className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type={showPassword ? "text" : "password"}
                placeholder="تأكيد كلمة المرور"
                value={formData.confirmPassword}
                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                className="w-full bg-white/10 border border-white/20 rounded-xl px-12 py-4 text-gray-800 dark:text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-300"
                required={!isLogin}
              />
            </div>
          )}

          <Button
            type="submit"
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 hover:from-blue-600 hover:via-purple-600 hover:to-pink-600 text-white py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 disabled:opacity-50"
          >
            {isLoading ? (
              <div className="flex items-center justify-center space-x-2">
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                <span>{isLogin ? "جاري تسجيل الدخول..." : "جاري إنشاء الحساب..."}</span>
              </div>
            ) : (
              <span>{isLogin ? "تسجيل الدخول" : "إنشاء حساب جديد"}</span>
            )}
          </Button>
        </form>

        {isLogin && (
          <div className="text-center mt-6">
            <Button className="bg-transparent hover:bg-transparent text-blue-600 dark:text-blue-400 p-0">
              نسيت كلمة المرور؟
            </Button>
          </div>
        )}

        {/* Terms */}
        {!isLogin && (
          <p className="text-xs text-gray-500 dark:text-gray-400 text-center mt-6">
            بإنشاء حساب، أنت توافق على <span className="text-blue-600 dark:text-blue-400">الشروط والأحكام</span> و{" "}
            <span className="text-blue-600 dark:text-blue-400">سياسة الخصوصية</span>
          </p>
        )}
      </Card>
    </div>
  )
}
