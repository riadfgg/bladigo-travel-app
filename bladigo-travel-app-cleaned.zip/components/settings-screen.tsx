"use client"

import { useState } from "react"
import { ArrowLeft, Globe, Moon, Sun, Bell, Shield, HelpCircle, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface SettingsScreenProps {
  onNavigate: (screen: string) => void
}

export function SettingsScreen({ onNavigate }: SettingsScreenProps) {
  const [darkMode, setDarkMode] = useState(false)
  const [notifications, setNotifications] = useState(true)
  const [language, setLanguage] = useState("English")

  const languages = [
    { code: "ar", name: "العربية", flag: "🇩🇿" },
    { code: "en", name: "English", flag: "🇺🇸" },
    { code: "fr", name: "Français", flag: "🇫🇷" },
    { code: "es", name: "Español", flag: "🇪🇸" },
    { code: "zh", name: "中文", flag: "🇨🇳" },
    { code: "ru", name: "Русский", flag: "🇷🇺" },
  ]

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-100/80 via-gray-100/80 to-zinc-100/80 dark:from-gray-900/80 dark:via-slate-900/80 dark:to-zinc-900/80"></div>

      <div className="relative z-10 p-6 pb-24">
        {/* Header */}
        <div className="flex items-center justify-between mb-6 pt-12">
          <Button
            onClick={() => onNavigate("home")}
            className="bg-white/20 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
          >
            <ArrowLeft className="w-6 h-6 text-gray-700 dark:text-gray-200" />
          </Button>
          <h1 className="text-2xl font-bold text-gray-800 dark:text-white">Settings</h1>
          <div className="w-12"></div>
        </div>

        <div className="space-y-4">
          {/* Language Settings */}
          <Card className="bg-white/20 backdrop-blur-md border border-white/30 rounded-2xl p-6">
            <div className="flex items-center space-x-3 mb-4">
              <Globe className="w-6 h-6 text-blue-600" />
              <h3 className="text-lg font-bold text-gray-800 dark:text-white">Language</h3>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {languages.map((lang) => (
                <Button
                  key={lang.code}
                  onClick={() => setLanguage(lang.name)}
                  className={`p-3 rounded-xl transition-all duration-300 ${
                    language === lang.name
                      ? "bg-gradient-to-r from-blue-500 to-cyan-500 text-white"
                      : "bg-white/20 hover:bg-white/30 text-gray-700 dark:text-gray-200"
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <span>{lang.flag}</span>
                    <span className="text-sm">{lang.name}</span>
                  </div>
                </Button>
              ))}
            </div>
          </Card>

          {/* Theme Settings */}
          <Card className="bg-white/20 backdrop-blur-md border border-white/30 rounded-2xl p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                {darkMode ? <Moon className="w-6 h-6 text-purple-600" /> : <Sun className="w-6 h-6 text-amber-600" />}
                <div>
                  <h3 className="text-lg font-bold text-gray-800 dark:text-white">Theme</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    {darkMode ? "Dark mode enabled" : "Light mode enabled"}
                  </p>
                </div>
              </div>
              <Button
                onClick={() => setDarkMode(!darkMode)}
                className={`w-16 h-8 rounded-full transition-all duration-300 ${
                  darkMode ? "bg-purple-500" : "bg-gray-300"
                }`}
              >
                <div
                  className={`w-6 h-6 bg-white rounded-full transition-all duration-300 transform ${
                    darkMode ? "translate-x-8" : "translate-x-1"
                  }`}
                />
              </Button>
            </div>
          </Card>

          {/* Notifications */}
          <Card className="bg-white/20 backdrop-blur-md border border-white/30 rounded-2xl p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Bell className="w-6 h-6 text-emerald-600" />
                <div>
                  <h3 className="text-lg font-bold text-gray-800 dark:text-white">Notifications</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Location-based travel alerts</p>
                </div>
              </div>
              <Button
                onClick={() => setNotifications(!notifications)}
                className={`w-16 h-8 rounded-full transition-all duration-300 ${
                  notifications ? "bg-emerald-500" : "bg-gray-300"
                }`}
              >
                <div
                  className={`w-6 h-6 bg-white rounded-full transition-all duration-300 transform ${
                    notifications ? "translate-x-8" : "translate-x-1"
                  }`}
                />
              </Button>
            </div>
          </Card>

          {/* Other Settings */}
          <div className="space-y-3">
            <Button className="w-full bg-white/20 backdrop-blur-md border border-white/30 hover:bg-white/30 rounded-2xl p-4 justify-start">
              <Shield className="w-6 h-6 text-red-600 mr-3" />
              <span className="text-gray-800 dark:text-white">Privacy & Security</span>
            </Button>

            <Button className="w-full bg-white/20 backdrop-blur-md border border-white/30 hover:bg-white/30 rounded-2xl p-4 justify-start">
              <HelpCircle className="w-6 h-6 text-blue-600 mr-3" />
              <span className="text-gray-800 dark:text-white">Help & Support</span>
            </Button>

            <Button className="w-full bg-white/20 backdrop-blur-md border border-white/30 hover:bg-white/30 rounded-2xl p-4 justify-start">
              <LogOut className="w-6 h-6 text-gray-600 mr-3" />
              <span className="text-gray-800 dark:text-white">Sign Out</span>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
