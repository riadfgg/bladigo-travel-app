"use client"

import { useState } from "react"
import { ArrowLeft, Globe, Moon, Sun, Bell, Shield, HelpCircle, MapPin, Smartphone, Volume2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { useTheme } from "@/components/theme-provider"
// Import language support
import { useLanguage } from "@/components/language-provider"

interface SettingsSectionProps {
  onBack: () => void
}

export function SettingsSection({ onBack }: SettingsSectionProps) {
  // Add language hook and update language state
  const { theme, setTheme } = useTheme()
  const { language, setLanguage: setAppLanguage, t, isRTL } = useLanguage()
  const [notifications, setNotifications] = useState(true)
  const [geoAlerts, setGeoAlerts] = useState(true)
  const [aiAssistant, setAiAssistant] = useState(true)
  const [culturalFirst, setCulturalFirst] = useState(true)

  // Update language selection
  const languages = [
    { code: "ar", name: "العربية", flag: "🇩🇿" },
    { code: "en", name: "English", flag: "🇬🇧" },
    { code: "fr", name: "Français", flag: "🇫🇷" },
    { code: "es", name: "Español", flag: "🇪🇸" },
    { code: "zh", name: "中文", flag: "🇨🇳" },
    { code: "ru", name: "Русский", flag: "🇷🇺" },
  ]

  const themeOptions = [
    { value: "light", label: "Light", icon: Sun },
    { value: "dark", label: "Dark", icon: Moon },
    { value: "system", label: "System", icon: Smartphone },
  ]

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <Button
          onClick={onBack}
          className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
        >
          <ArrowLeft className="w-6 h-6 text-gray-700 dark:text-gray-200" />
        </Button>
        <h1 className="text-2xl font-bold text-gray-800 dark:text-white">{t("settings.title")}</h1>
        <div className="w-12"></div>
      </div>

      {/* Language Settings */}
      <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
        <div className="flex items-center space-x-3 mb-4">
          <Globe className="w-6 h-6 text-blue-600" />
          <h3 className="text-lg font-bold text-gray-800 dark:text-white">{t("settings.language")}</h3>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {languages.map((lang) => (
            <Button
              key={lang.code}
              // Update language button click
              onClick={() => setAppLanguage(lang.code)}
              className={`p-3 rounded-xl transition-all duration-300 ${
                language === lang.code
                  ? "bg-gradient-to-r from-blue-500 to-cyan-500 text-white"
                  : "bg-white/20 dark:bg-white/10 hover:bg-white/30 text-gray-700 dark:text-gray-200"
              }`}
            >
              <div className="flex items-center space-x-2">
                <span>{lang.flag}</span>
                <span className="text-sm">{lang.name}</span>
              </div>
            </Button>
          ))}
        </div>
      </Card>

      {/* Theme Settings */}
      <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
        <div className="flex items-center space-x-3 mb-4">
          <Sun className="w-6 h-6 text-amber-600" />
          <h3 className="text-lg font-bold text-gray-800 dark:text-white">{t("settings.theme")}</h3>
        </div>
        <div className="grid grid-cols-3 gap-3">
          {themeOptions.map((option) => {
            const IconComponent = option.icon
            return (
              <Button
                key={option.value}
                onClick={() => setTheme(option.value as any)}
                className={`p-3 rounded-xl transition-all duration-300 ${
                  theme === option.value
                    ? "bg-gradient-to-r from-amber-500 to-orange-500 text-white"
                    : "bg-white/20 dark:bg-white/10 hover:bg-white/30 text-gray-700 dark:text-gray-200"
                }`}
              >
                <div className="flex flex-col items-center space-y-1">
                  <IconComponent className="w-5 h-5" />
                  <span className="text-xs">{option.label}</span>
                </div>
              </Button>
            )
          })}
        </div>
      </Card>

      {/* Notification Settings */}
      <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
        <div className="flex items-center space-x-3 mb-4">
          <Bell className="w-6 h-6 text-emerald-600" />
          <h3 className="text-lg font-bold text-gray-800 dark:text-white">Notifications</h3>
        </div>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-gray-800 dark:text-white">Push Notifications</p>
              <p className="text-sm text-gray-600 dark:text-gray-300">General app notifications</p>
            </div>
            <Button
              onClick={() => setNotifications(!notifications)}
              className={`relative w-16 h-8 rounded-full transition-all duration-300 ${
                notifications ? "bg-emerald-500" : "bg-gray-300"
              }`}
            >
              <div
                className={`absolute w-6 h-6 bg-white rounded-full transition-all duration-300 transform ${
                  notifications ? "translate-x-8" : "translate-x-1"
                } top-1`}
              />
            </Button>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-gray-800 dark:text-white">Geo-based Alerts</p>
              <p className="text-sm text-gray-600 dark:text-gray-300">Location-based travel alerts</p>
            </div>
            <Button
              onClick={() => setGeoAlerts(!geoAlerts)}
              className={`relative w-16 h-8 rounded-full transition-all duration-300 ${
                geoAlerts ? "bg-emerald-500" : "bg-gray-300"
              }`}
            >
              <div
                className={`absolute w-6 h-6 bg-white rounded-full transition-all duration-300 transform ${
                  geoAlerts ? "translate-x-8" : "translate-x-1"
                } top-1`}
              />
            </Button>
          </div>
        </div>
      </Card>

      {/* AI Settings */}
      <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
        <div className="flex items-center space-x-3 mb-4">
          <Volume2 className="w-6 h-6 text-purple-600" />
          <h3 className="text-lg font-bold text-gray-800 dark:text-white">AI Assistant</h3>
        </div>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-gray-800 dark:text-white">Enable AI Assistant</p>
              <p className="text-sm text-gray-600 dark:text-gray-300">Smart travel recommendations</p>
            </div>
            <Button
              onClick={() => setAiAssistant(!aiAssistant)}
              className={`relative w-16 h-8 rounded-full transition-all duration-300 ${
                aiAssistant ? "bg-purple-500" : "bg-gray-300"
              }`}
            >
              <div
                className={`absolute w-6 h-6 bg-white rounded-full transition-all duration-300 transform ${
                  aiAssistant ? "translate-x-8" : "translate-x-1"
                } top-1`}
              />
            </Button>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-gray-800 dark:text-white">Cultural Places First</p>
              <p className="text-sm text-gray-600 dark:text-gray-300">Prioritize cultural attractions</p>
            </div>
            <Button
              onClick={() => setCulturalFirst(!culturalFirst)}
              className={`relative w-16 h-8 rounded-full transition-all duration-300 ${
                culturalFirst ? "bg-amber-500" : "bg-gray-300"
              }`}
            >
              <div
                className={`absolute w-6 h-6 bg-white rounded-full transition-all duration-300 transform ${
                  culturalFirst ? "translate-x-8" : "translate-x-1"
                } top-1`}
              />
            </Button>
          </div>
        </div>
      </Card>

      {/* Other Settings */}
      <div className="space-y-3">
        <Button className="w-full bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 rounded-2xl p-4 justify-start">
          <Shield className="w-6 h-6 text-red-600 mr-3" />
          <div className="text-left">
            <p className="font-medium text-gray-800 dark:text-white">Privacy & Security</p>
            <p className="text-sm text-gray-600 dark:text-gray-300">Manage your data and privacy</p>
          </div>
        </Button>

        <Button className="w-full bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 rounded-2xl p-4 justify-start">
          <HelpCircle className="w-6 h-6 text-blue-600 mr-3" />
          <div className="text-left">
            <p className="font-medium text-gray-800 dark:text-white">Help & Support</p>
            <p className="text-sm text-gray-600 dark:text-gray-300">Get help and contact support</p>
          </div>
        </Button>

        <Button className="w-full bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 rounded-2xl p-4 justify-start">
          <MapPin className="w-6 h-6 text-emerald-600 mr-3" />
          <div className="text-left">
            <p className="font-medium text-gray-800 dark:text-white">Clear Saved Trips</p>
            <p className="text-sm text-gray-600 dark:text-gray-300">Remove all saved trip data</p>
          </div>
        </Button>
      </div>

      {/* App Info */}
      <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6 text-center">
        <h3 className="text-lg font-bold bg-gradient-to-r from-amber-600 via-blue-600 to-emerald-600 bg-clip-text text-transparent mb-2">
          BladiGo
        </h3>
        <p className="text-sm text-gray-600 dark:text-gray-300">Version 1.0.0</p>
        <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">Premium Algeria Tourism Experience</p>
      </Card>
    </div>
  )
}
