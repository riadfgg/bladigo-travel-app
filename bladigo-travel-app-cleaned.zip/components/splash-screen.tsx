"use client"

import { useEffect, useState } from "react"
import { Sparkles } from "lucide-react"

export function SplashScreen() {
  const [showLogo, setShowLogo] = useState(false)
  const [showSlogan, setShowSlogan] = useState(false)
  const [showCar, setShowCar] = useState(false)

  useEffect(() => {
    // إظهار اللوغو أولاً
    const timer1 = setTimeout(() => setShowLogo(true), 500)

    // إظهار الشعار
    const timer2 = setTimeout(() => setShowSlogan(true), 1200)

    // إظهار السيارة
    const timer3 = setTimeout(() => setShowCar(true), 1800)

    return () => {
      clearTimeout(timer1)
      clearTimeout(timer2)
      clearTimeout(timer3)
    }
  }, [])

  return (
    <div className="min-h-screen relative overflow-hidden bg-white">
      {/* خلفية بيضاء بسيطة */}
      <div className="absolute inset-0 bg-gray-50/30"></div>

      {/* تأثير بسيط في الخلفية */}
      <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-blue-100/20 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-1/4 right-1/4 w-48 h-48 bg-emerald-100/20 rounded-full blur-2xl animate-pulse delay-1000"></div>

      {/* المحتوى الرئيسي */}
      <div className="relative z-10 flex items-center justify-center min-h-screen">
        <div className="text-center px-6">
          {/* اللوغو */}
          <div
            className={`transition-all duration-1000 ${showLogo ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
          >
            <div className="flex items-center justify-center mb-6">
              <Sparkles className="w-10 h-10 text-amber-500 mr-4 animate-pulse" />
              <h1 className="text-7xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-emerald-600 bg-clip-text text-transparent drop-shadow-lg">
                BladiGo
              </h1>
              <Sparkles className="w-10 h-10 text-amber-500 ml-4 animate-pulse delay-500" />
            </div>
          </div>

          {/* الشعار */}
          <div
            className={`transition-all duration-1000 delay-300 ${showSlogan ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
          >
            <p className="text-3xl text-gray-700 font-medium mb-3 drop-shadow-sm">اكتشف جمال الجزائر</p>
            <p className="text-xl text-gray-600 font-light mb-8">رحلتك تبدأ من هنا</p>
          </div>

          {/* سيارة السفر */}
          <div
            className={`transition-all duration-1000 delay-500 ${showCar ? "opacity-100 scale-100" : "opacity-0 scale-90"}`}
          >
            <div className="relative w-32 h-32 mx-auto mb-8">
              {/* سيارة السفر */}
              <div className="text-8xl animate-bounce">🚗</div>
              {/* تأثير الحركة */}
              <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2">
                <div className="flex space-x-1">
                  <div className="w-2 h-1 bg-gray-400 rounded-full animate-pulse"></div>
                  <div className="w-2 h-1 bg-gray-400 rounded-full animate-pulse delay-100"></div>
                  <div className="w-2 h-1 bg-gray-400 rounded-full animate-pulse delay-200"></div>
                </div>
              </div>
            </div>
          </div>

          {/* مؤشر التحميل */}
          <div className={`transition-all duration-500 delay-1000 ${showCar ? "opacity-100" : "opacity-0"}`}>
            <div className="flex justify-center space-x-2 mb-4">
              <div className="w-3 h-3 bg-blue-500 rounded-full animate-bounce"></div>
              <div className="w-3 h-3 bg-purple-500 rounded-full animate-bounce delay-100"></div>
              <div className="w-3 h-3 bg-emerald-500 rounded-full animate-bounce delay-200"></div>
            </div>
            <p className="text-gray-500 text-sm animate-pulse">جاري التحميل...</p>
          </div>
        </div>
      </div>

      {/* شريط التقدم في الأسفل */}
      <div className="absolute bottom-8 left-8 right-8">
        <div className="w-full bg-gray-200 rounded-full h-1">
          <div
            className="bg-gradient-to-r from-blue-500 to-emerald-500 h-1 rounded-full animate-pulse"
            style={{ width: "70%" }}
          ></div>
        </div>
      </div>

      {/* عناصر ديكورية إضافية */}
      <div className="absolute top-10 right-10 text-2xl animate-bounce delay-1000">✈️</div>
      <div className="absolute bottom-20 left-10 text-2xl animate-bounce delay-1500">🏔️</div>
      <div className="absolute top-1/3 left-10 text-xl animate-pulse delay-2000">🌟</div>
      <div className="absolute bottom-1/3 right-10 text-xl animate-pulse delay-2500">🗺️</div>
    </div>
  )
}
