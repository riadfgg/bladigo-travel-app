"use client"

import { Search, Sparkles, Bell } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useLanguage } from "@/components/language-provider"
import { useState, useEffect } from "react"

interface StickyHeaderProps {
  searchQuery: string
  setSearchQuery: (query: string) => void
  onNavigate: (section: string) => void
  showNotifications?: boolean
}

export function StickyHeader({
  searchQuery,
  setSearchQuery,
  onNavigate,
  showNotifications = false,
}: StickyHeaderProps) {
  const [isVisible, setIsVisible] = useState(true)
  const [lastScrollY, setLastScrollY] = useState(0)
  const { t } = useLanguage()

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY

      if (currentScrollY > lastScrollY && currentScrollY > 100) {
        // Scrolling down & past 100px
        setIsVisible(false)
      } else if (currentScrollY < lastScrollY) {
        // Scrolling up
        setIsVisible(true)
      }

      setLastScrollY(currentScrollY)
    }

    window.addEventListener("scroll", handleScroll, { passive: true })
    return () => window.removeEventListener("scroll", handleScroll)
  }, [lastScrollY])

  return (
    <div
      className={`fixed top-0 left-0 right-0 z-40 bg-gradient-to-r from-blue-600/95 to-purple-600/95 backdrop-blur-xl border-b border-white/20 transition-all duration-300 ${
        isVisible ? "translate-y-0" : "-translate-y-full"
      }`}
    >
      <div className="px-4 py-3 pt-12">
        {/* Logo & Actions */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <h1 className="text-xl font-bold text-white">{t("app.name")}</h1>
            <Sparkles className="w-5 h-5 text-yellow-300 animate-pulse" />
          </div>

          <div className="flex items-center space-x-2">
            {showNotifications && (
              <Button className="bg-white/20 hover:bg-white/30 text-white border border-white/30 rounded-full p-2">
                <Bell className="w-4 h-4" />
              </Button>
            )}
            <Button
              onClick={() => onNavigate("ai-assistant")}
              className="bg-white/20 hover:bg-white/30 text-white border border-white/30 rounded-full px-4 py-2 text-sm font-medium"
            >
              <Sparkles className="w-4 h-4 mr-1" />
              AI
            </Button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-xl px-4 py-2.5">
          <div className="flex items-center space-x-3">
            <Search className="w-5 h-5 text-white/70" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t("common.search")}
              className="flex-1 bg-transparent placeholder-white/60 text-white text-sm outline-none"
            />
          </div>
        </div>
      </div>
    </div>
  )
}
