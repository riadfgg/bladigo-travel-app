"use client"

import { useState } from "react"
import { ArrowLeft, MapPin, Star, Navigation, Camera, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface TouristSpotsProps {
  onNavigate: (screen: string) => void
}

const touristSpots = [
  {
    id: 1,
    name: "Makam El Chahid",
    location: "Algiers",
    rating: 4.8,
    distance: "2.3 km",
    image: "/placeholder.svg?height=200&width=300",
    description: "Iconic monument commemorating martyrs of the Algerian War",
    estimatedTime: "1-2 hours",
  },
  {
    id: 2,
    name: "Timgad Ruins",
    location: "Batna",
    rating: 4.9,
    distance: "15.7 km",
    image: "/placeholder.svg?height=200&width=300",
    description: "UNESCO World Heritage Roman archaeological site",
    estimatedTime: "3-4 hours",
  },
  {
    id: 3,
    name: "Fort Santa Cruz",
    location: "Oran",
    rating: 4.7,
    distance: "8.2 km",
    image: "/placeholder.svg?height=200&width=300",
    description: "Historic fortress with breathtaking sunset views",
    estimatedTime: "2-3 hours",
  },
  {
    id: 4,
    name: "Casbah of Algiers",
    location: "Algiers",
    rating: 4.6,
    distance: "1.8 km",
    image: "/placeholder.svg?height=200&width=300",
    description: "Historic medina and UNESCO World Heritage site",
    estimatedTime: "4-5 hours",
  },
]

export function TouristSpots({ onNavigate }: TouristSpotsProps) {
  const [selectedSpot, setSelectedSpot] = useState<number | null>(null)

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-amber-100/80 via-blue-100/80 to-emerald-100/80 dark:from-gray-900/80 dark:via-blue-900/80 dark:to-emerald-900/80"></div>

      <div className="relative z-10 p-6 pb-24">
        {/* Header */}
        <div className="flex items-center justify-between mb-6 pt-12">
          <Button
            onClick={() => onNavigate("home")}
            className="bg-white/20 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
          >
            <ArrowLeft className="w-6 h-6 text-gray-700 dark:text-gray-200" />
          </Button>
          <h1 className="text-2xl font-bold text-gray-800 dark:text-white">Tourist Spots</h1>
          <div className="w-12"></div>
        </div>

        {/* Search and Filter */}
        <div className="mb-6 bg-white/20 backdrop-blur-md rounded-2xl border border-white/30 p-4">
          <div className="flex items-center space-x-2">
            <MapPin className="w-5 h-5 text-blue-600" />
            <input
              type="text"
              placeholder="Search destinations..."
              className="flex-1 bg-transparent placeholder-gray-500 text-gray-700 dark:text-gray-200 outline-none"
            />
          </div>
        </div>

        {/* Tourist Spots Grid */}
        <div className="space-y-4">
          {touristSpots.map((spot) => (
            <Card
              key={spot.id}
              className="bg-white/20 backdrop-blur-md border border-white/30 rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 cursor-pointer"
              onClick={() => setSelectedSpot(selectedSpot === spot.id ? null : spot.id)}
            >
              <div className="relative">
                <img src={spot.image || "/placeholder.svg"} alt={spot.name} className="w-full h-48 object-cover" />
                <div className="absolute top-4 right-4 bg-black/50 backdrop-blur-sm rounded-full px-3 py-1">
                  <div className="flex items-center space-x-1">
                    <Star className="w-4 h-4 text-yellow-400 fill-current" />
                    <span className="text-white text-sm font-medium">{spot.rating}</span>
                  </div>
                </div>
              </div>

              <div className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="text-lg font-bold text-gray-800 dark:text-white">{spot.name}</h3>
                    <p className="text-gray-600 dark:text-gray-300">{spot.location}</p>
                  </div>
                  <div className="flex items-center space-x-1 text-blue-600">
                    <Navigation className="w-4 h-4" />
                    <span className="text-sm font-medium">{spot.distance}</span>
                  </div>
                </div>

                <p className="text-gray-600 dark:text-gray-300 text-sm mb-3">{spot.description}</p>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-1 text-emerald-600">
                    <Clock className="w-4 h-4" />
                    <span className="text-sm">{spot.estimatedTime}</span>
                  </div>
                  <Button className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white rounded-full px-4 py-2 text-sm">
                    Get Directions
                  </Button>
                </div>

                {selectedSpot === spot.id && (
                  <div className="mt-4 pt-4 border-t border-white/20 space-y-3 animate-in slide-in-from-top duration-300">
                    <div className="grid grid-cols-2 gap-3">
                      <Button className="bg-white/20 hover:bg-white/30 text-gray-700 dark:text-gray-200 rounded-xl">
                        <Camera className="w-4 h-4 mr-2" />
                        Photos
                      </Button>
                      <Button className="bg-white/20 hover:bg-white/30 text-gray-700 dark:text-gray-200 rounded-xl">
                        <MapPin className="w-4 h-4 mr-2" />
                        Map View
                      </Button>
                    </div>
                    <Button
                      onClick={() => onNavigate("hotels")}
                      className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white rounded-xl"
                    >
                      Find Nearby Hotels
                    </Button>
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
