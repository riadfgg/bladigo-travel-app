"use client"

import { useState } from "react"
import { ArrowLeft, Calendar, MapPin, Users, DollarSign, Clock, Download, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface TripPlannerProps {
  onBack: () => void
}

interface TripPlan {
  day: number
  activities: {
    time: string
    activity: string
    location: string
    duration: string
    cost: string
  }[]
  totalCost: string
}

export function TripPlanner({ onBack }: TripPlannerProps) {
  const [step, setStep] = useState(1)
  const [tripData, setTripData] = useState({
    destination: "",
    duration: "",
    travelers: "",
    budget: "",
    interests: [] as string[],
    dates: "",
  })
  const [generatedPlan, setGeneratedPlan] = useState<TripPlan[]>([])
  const [isGenerating, setIsGenerating] = useState(false)

  const destinations = ["Algiers", "Oran", "Constantine", "Batna", "Tlemcen", "Ghardaia", "Tamanrasset"]
  const durations = ["1-2 days", "3-5 days", "1 week", "2 weeks", "1 month"]
  const travelerTypes = ["Solo", "Couple", "Family", "Friends", "Group"]
  const budgetRanges = ["Budget (€50-100/day)", "Mid-range (€100-200/day)", "Luxury (€200+/day)"]
  const interestOptions = ["History", "Culture", "Nature", "Food", "Adventure", "Relaxation", "Photography", "Shopping"]

  const toggleInterest = (interest: string) => {
    setTripData((prev) => ({
      ...prev,
      interests: prev.interests.includes(interest)
        ? prev.interests.filter((i) => i !== interest)
        : [...prev.interests, interest],
    }))
  }

  const generateTrip = async () => {
    setIsGenerating(true)

    // Simulate AI trip generation
    await new Promise((resolve) => setTimeout(resolve, 3000))

    const samplePlan: TripPlan[] = [
      {
        day: 1,
        activities: [
          {
            time: "09:00",
            activity: "Arrival & Hotel Check-in",
            location: "Sofitel Algiers Hamma Garden",
            duration: "1 hour",
            cost: "€0",
          },
          {
            time: "10:30",
            activity: "Explore Casbah of Algiers",
            location: "Historic Medina",
            duration: "3 hours",
            cost: "€15",
          },
          {
            time: "14:00",
            activity: "Traditional Lunch",
            location: "Restaurant El Djenina",
            duration: "1.5 hours",
            cost: "€25",
          },
          {
            time: "16:00",
            activity: "Visit Makam El Chahid",
            location: "Martyrs' Memorial",
            duration: "2 hours",
            cost: "€10",
          },
          {
            time: "19:00",
            activity: "Sunset at Notre Dame d'Afrique",
            location: "Basilica",
            duration: "1 hour",
            cost: "€5",
          },
        ],
        totalCost: "€55",
      },
      {
        day: 2,
        activities: [
          {
            time: "08:00",
            activity: "Breakfast at Hotel",
            location: "Hotel Restaurant",
            duration: "1 hour",
            cost: "€20",
          },
          {
            time: "09:30",
            activity: "Day Trip to Tipaza",
            location: "Roman Ruins",
            duration: "6 hours",
            cost: "€40",
          },
          {
            time: "16:00",
            activity: "Beach Time at Tipaza",
            location: "Mediterranean Coast",
            duration: "2 hours",
            cost: "€0",
          },
          {
            time: "19:00",
            activity: "Seafood Dinner",
            location: "Coastal Restaurant",
            duration: "2 hours",
            cost: "€35",
          },
        ],
        totalCost: "€95",
      },
    ]

    setGeneratedPlan(samplePlan)
    setIsGenerating(false)
    setStep(3)
  }

  const exportToPDF = () => {
    alert("Trip plan exported to PDF! (Feature would be implemented with PDF generation library)")
  }

  if (step === 1) {
    return (
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <Button
            onClick={onBack}
            className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
          >
            <ArrowLeft className="w-6 h-6 text-gray-700 dark:text-gray-200" />
          </Button>
          <div className="text-center">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-6 h-6 text-emerald-600 animate-pulse" />
              <h1 className="text-xl font-bold text-gray-800 dark:text-white">AI Trip Planner</h1>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-300">Step 1 of 2</p>
          </div>
          <div className="w-12"></div>
        </div>

        <div className="space-y-6">
          {/* Destination */}
          <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
            <div className="flex items-center space-x-3 mb-4">
              <MapPin className="w-6 h-6 text-emerald-600" />
              <h3 className="text-lg font-bold text-gray-800 dark:text-white">Destination</h3>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {destinations.map((destination) => (
                <Button
                  key={destination}
                  onClick={() => setTripData((prev) => ({ ...prev, destination }))}
                  className={`p-3 rounded-xl transition-all duration-300 ${
                    tripData.destination === destination
                      ? "bg-gradient-to-r from-emerald-500 to-teal-500 text-white"
                      : "bg-white/20 dark:bg-white/10 hover:bg-white/30 text-gray-700 dark:text-gray-200"
                  }`}
                >
                  {destination}
                </Button>
              ))}
            </div>
          </Card>

          {/* Duration */}
          <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
            <div className="flex items-center space-x-3 mb-4">
              <Calendar className="w-6 h-6 text-blue-600" />
              <h3 className="text-lg font-bold text-gray-800 dark:text-white">Duration</h3>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {durations.map((duration) => (
                <Button
                  key={duration}
                  onClick={() => setTripData((prev) => ({ ...prev, duration }))}
                  className={`p-3 rounded-xl transition-all duration-300 text-sm ${
                    tripData.duration === duration
                      ? "bg-gradient-to-r from-blue-500 to-cyan-500 text-white"
                      : "bg-white/20 dark:bg-white/10 hover:bg-white/30 text-gray-700 dark:text-gray-200"
                  }`}
                >
                  {duration}
                </Button>
              ))}
            </div>
          </Card>

          {/* Travelers */}
          <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
            <div className="flex items-center space-x-3 mb-4">
              <Users className="w-6 h-6 text-purple-600" />
              <h3 className="text-lg font-bold text-gray-800 dark:text-white">Travelers</h3>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {travelerTypes.map((type) => (
                <Button
                  key={type}
                  onClick={() => setTripData((prev) => ({ ...prev, travelers: type }))}
                  className={`p-3 rounded-xl transition-all duration-300 ${
                    tripData.travelers === type
                      ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white"
                      : "bg-white/20 dark:bg-white/10 hover:bg-white/30 text-gray-700 dark:text-gray-200"
                  }`}
                >
                  {type}
                </Button>
              ))}
            </div>
          </Card>

          {/* Budget */}
          <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
            <div className="flex items-center space-x-3 mb-4">
              <DollarSign className="w-6 h-6 text-amber-600" />
              <h3 className="text-lg font-bold text-gray-800 dark:text-white">Budget</h3>
            </div>
            <div className="space-y-3">
              {budgetRanges.map((budget) => (
                <Button
                  key={budget}
                  onClick={() => setTripData((prev) => ({ ...prev, budget }))}
                  className={`w-full p-3 rounded-xl transition-all duration-300 text-sm ${
                    tripData.budget === budget
                      ? "bg-gradient-to-r from-amber-500 to-orange-500 text-white"
                      : "bg-white/20 dark:bg-white/10 hover:bg-white/30 text-gray-700 dark:text-gray-200"
                  }`}
                >
                  {budget}
                </Button>
              ))}
            </div>
          </Card>

          {/* Continue Button */}
          <Button
            onClick={() => setStep(2)}
            disabled={!tripData.destination || !tripData.duration || !tripData.travelers || !tripData.budget}
            className="w-full h-16 bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-600 hover:via-teal-600 hover:to-cyan-600 disabled:opacity-50 text-white rounded-2xl shadow-lg"
          >
            <span className="text-lg font-bold">Continue to Interests</span>
          </Button>
        </div>
      </div>
    )
  }

  if (step === 2) {
    return (
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <Button
            onClick={() => setStep(1)}
            className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
          >
            <ArrowLeft className="w-6 h-6 text-gray-700 dark:text-gray-200" />
          </Button>
          <div className="text-center">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-6 h-6 text-emerald-600 animate-pulse" />
              <h1 className="text-xl font-bold text-gray-800 dark:text-white">AI Trip Planner</h1>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-300">Step 2 of 2</p>
          </div>
          <div className="w-12"></div>
        </div>

        <div className="space-y-6">
          {/* Interests */}
          <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">What interests you most?</h3>
            <div className="grid grid-cols-2 gap-3">
              {interestOptions.map((interest) => (
                <Button
                  key={interest}
                  onClick={() => toggleInterest(interest)}
                  className={`p-3 rounded-xl transition-all duration-300 ${
                    tripData.interests.includes(interest)
                      ? "bg-gradient-to-r from-amber-500 to-orange-500 text-white"
                      : "bg-white/20 dark:bg-white/10 hover:bg-white/30 text-gray-700 dark:text-gray-200"
                  }`}
                >
                  {interest}
                </Button>
              ))}
            </div>
          </Card>

          {/* Travel Dates */}
          <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">Travel Dates (Optional)</h3>
            <input
              type="date"
              value={tripData.dates}
              onChange={(e) => setTripData((prev) => ({ ...prev, dates: e.target.value }))}
              className="w-full bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-xl p-3 text-gray-700 dark:text-gray-200 outline-none"
            />
          </Card>

          {/* Generate Button */}
          <Button
            onClick={generateTrip}
            disabled={tripData.interests.length === 0 || isGenerating}
            className="w-full h-16 bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-600 hover:via-teal-600 hover:to-cyan-600 disabled:opacity-50 text-white rounded-2xl shadow-lg"
          >
            {isGenerating ? (
              <div className="flex items-center space-x-3">
                <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                <span className="text-lg font-bold">AI is creating your perfect trip...</span>
              </div>
            ) : (
              <div className="flex items-center space-x-3">
                <Sparkles className="w-6 h-6" />
                <span className="text-lg font-bold">Generate My Perfect Trip</span>
              </div>
            )}
          </Button>
        </div>
      </div>
    )
  }

  if (step === 3) {
    return (
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <Button
            onClick={() => setStep(2)}
            className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
          >
            <ArrowLeft className="w-6 h-6 text-gray-700 dark:text-gray-200" />
          </Button>
          <div className="text-center">
            <h1 className="text-xl font-bold text-gray-800 dark:text-white">Your Perfect Trip</h1>
            <p className="text-sm text-gray-600 dark:text-gray-300">
              {tripData.destination} • {tripData.duration}
            </p>
          </div>
          <Button
            onClick={exportToPDF}
            className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white rounded-full p-3"
          >
            <Download className="w-6 h-6" />
          </Button>
        </div>

        {/* Trip Plan */}
        <div className="space-y-4">
          {generatedPlan.map((day) => (
            <Card
              key={day.day}
              className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-gray-800 dark:text-white">Day {day.day}</h3>
                <div className="text-right">
                  <p className="text-sm text-gray-600 dark:text-gray-300">Total Cost</p>
                  <p className="text-xl font-bold text-emerald-600">{day.totalCost}</p>
                </div>
              </div>

              <div className="space-y-3">
                {day.activities.map((activity, index) => (
                  <div key={index} className="bg-white/10 rounded-xl p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <Clock className="w-4 h-4 text-blue-600" />
                          <span className="text-sm font-medium text-blue-600">{activity.time}</span>
                        </div>
                        <h4 className="font-bold text-gray-800 dark:text-white">{activity.activity}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-300">{activity.location}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-500">{activity.duration}</p>
                        <p className="font-bold text-emerald-600">{activity.cost}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          ))}
        </div>

        {/* Total Summary */}
        <Card className="bg-gradient-to-r from-emerald-500/20 to-teal-500/20 backdrop-blur-md border border-white/30 rounded-2xl p-6">
          <div className="text-center">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-2">Trip Summary</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-300">Total Duration</p>
                <p className="text-xl font-bold text-emerald-600">{generatedPlan.length} Days</p>
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-300">Estimated Cost</p>
                <p className="text-xl font-bold text-emerald-600">
                  €{generatedPlan.reduce((total, day) => total + Number.parseInt(day.totalCost.replace("€", "")), 0)}
                </p>
              </div>
            </div>
          </div>
        </Card>
      </div>
    )
  }

  return null
}
