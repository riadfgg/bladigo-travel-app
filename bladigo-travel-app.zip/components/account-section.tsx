"use client"

import { useState } from "react"
import { ArrowLeft, Mail, Phone, MapPin, Camera, Edit3, Star, Heart, Calendar, Award, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface AccountSectionProps {
  onBack: () => void
}

export function AccountSection({ onBack }: AccountSectionProps) {
  const [user] = useState({
    name: "Ahmed Benali",
    email: "ahmed.benali@email.com",
    phone: "+213 555 123 456",
    location: "Algiers, Algeria",
    avatar: "/placeholder.svg?height=120&width=120&text=AB",
    joinDate: "March 2024",
    tripsCompleted: 12,
    favoriteSpots: 28,
    reviews: 15,
    points: 2450,
    level: "Explorer",
  })

  const recentTrips = [
    {
      id: 1,
      destination: "Timgad Ruins",
      date: "Dec 2024",
      image: "/placeholder.svg?height=80&width=80&text=Timgad",
      rating: 5,
      cost: "€150",
    },
    {
      id: 2,
      destination: "Fort Santa Cruz",
      date: "Nov 2024",
      image: "/placeholder.svg?height=80&width=80&text=Fort",
      rating: 4,
      cost: "€120",
    },
    {
      id: 3,
      destination: "Casbah of Algiers",
      date: "Oct 2024",
      image: "/placeholder.svg?height=80&width=80&text=Casbah",
      rating: 5,
      cost: "€80",
    },
  ]

  const achievements = [
    { name: "First Trip", icon: "🎯", earned: true },
    { name: "Culture Explorer", icon: "🏛️", earned: true },
    { name: "Food Lover", icon: "🍽️", earned: true },
    { name: "Adventure Seeker", icon: "🏔️", earned: false },
    { name: "Local Expert", icon: "🗺️", earned: false },
    { name: "Travel Master", icon: "👑", earned: false },
  ]

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <Button
          onClick={onBack}
          className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
        >
          <ArrowLeft className="w-6 h-6 text-gray-700 dark:text-gray-200" />
        </Button>
        <h1 className="text-2xl font-bold text-gray-800 dark:text-white">My Account</h1>
        <Button className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3">
          <Edit3 className="w-6 h-6 text-gray-700 dark:text-gray-200" />
        </Button>
      </div>

      {/* Profile Card */}
      <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
        <div className="flex items-center space-x-4 mb-6">
          <div className="relative">
            <img
              src={user.avatar || "/placeholder.svg"}
              alt={user.name}
              className="w-20 h-20 rounded-full object-cover border-4 border-white/50"
            />
            <Button className="absolute -bottom-2 -right-2 bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 rounded-full p-2">
              <Camera className="w-4 h-4 text-white" />
            </Button>
          </div>
          <div className="flex-1">
            <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-1">{user.name}</h2>
            <div className="flex items-center space-x-2 mb-2">
              <Award className="w-4 h-4 text-amber-500" />
              <span className="text-amber-600 font-medium">{user.level}</span>
              <span className="text-gray-500">•</span>
              <span className="text-blue-600 font-medium">{user.points} pts</span>
            </div>
            <p className="text-gray-600 dark:text-gray-300 text-sm">Traveler since {user.joinDate}</p>
          </div>
        </div>

        {/* Contact Info */}
        <div className="space-y-3">
          <div className="flex items-center space-x-3">
            <Mail className="w-5 h-5 text-blue-600" />
            <span className="text-gray-700 dark:text-gray-200">{user.email}</span>
          </div>
          <div className="flex items-center space-x-3">
            <Phone className="w-5 h-5 text-green-600" />
            <span className="text-gray-700 dark:text-gray-200">{user.phone}</span>
          </div>
          <div className="flex items-center space-x-3">
            <MapPin className="w-5 h-5 text-red-600" />
            <span className="text-gray-700 dark:text-gray-200">{user.location}</span>
          </div>
        </div>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-4 text-center">
          <div className="text-2xl font-bold text-blue-600 mb-1">{user.tripsCompleted}</div>
          <div className="text-sm text-gray-600 dark:text-gray-300">Trips</div>
        </Card>
        <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-4 text-center">
          <div className="text-2xl font-bold text-red-600 mb-1">{user.favoriteSpots}</div>
          <div className="text-sm text-gray-600 dark:text-gray-300">Favorites</div>
        </Card>
        <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-4 text-center">
          <div className="text-2xl font-bold text-amber-600 mb-1">{user.reviews}</div>
          <div className="text-sm text-gray-600 dark:text-gray-300">Reviews</div>
        </Card>
      </div>

      {/* Achievements */}
      <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
        <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">Achievements</h3>
        <div className="grid grid-cols-3 gap-3">
          {achievements.map((achievement, index) => (
            <div
              key={index}
              className={`text-center p-3 rounded-xl transition-all duration-300 ${
                achievement.earned
                  ? "bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-300/30"
                  : "bg-white/10 border border-gray-300/30 opacity-50"
              }`}
            >
              <div className="text-2xl mb-1">{achievement.icon}</div>
              <div className="text-xs text-gray-700 dark:text-gray-200">{achievement.name}</div>
            </div>
          ))}
        </div>
      </Card>

      {/* Recent Trips */}
      <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
        <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">Recent Trips</h3>
        <div className="space-y-3">
          {recentTrips.map((trip) => (
            <div key={trip.id} className="flex items-center space-x-4 p-3 bg-white/10 rounded-xl">
              <img
                src={trip.image || "/placeholder.svg"}
                alt={trip.destination}
                className="w-12 h-12 rounded-lg object-cover"
              />
              <div className="flex-1">
                <h4 className="font-medium text-gray-800 dark:text-white">{trip.destination}</h4>
                <p className="text-sm text-gray-600 dark:text-gray-300">{trip.date}</p>
              </div>
              <div className="text-right">
                <div className="flex items-center space-x-1 mb-1">
                  {[...Array(trip.rating)].map((_, i) => (
                    <Star key={i} className="w-3 h-3 text-amber-500 fill-current" />
                  ))}
                </div>
                <p className="text-sm font-medium text-emerald-600">{trip.cost}</p>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-4">
        <Button className="h-16 bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 rounded-2xl">
          <div className="flex flex-col items-center space-y-1">
            <Heart className="w-6 h-6 text-red-600" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-200">My Favorites</span>
          </div>
        </Button>
        <Button className="h-16 bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 rounded-2xl">
          <div className="flex flex-col items-center space-y-1">
            <Calendar className="w-6 h-6 text-blue-600" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-200">Trip History</span>
          </div>
        </Button>
      </div>

      {/* Sign Out */}
      <Button className="w-full bg-red-500/20 hover:bg-red-500/30 border border-red-300/30 text-red-600 dark:text-red-400 rounded-2xl p-4">
        <LogOut className="w-5 h-5 mr-3" />
        <span className="font-medium">Sign Out</span>
      </Button>
    </div>
  )
}
