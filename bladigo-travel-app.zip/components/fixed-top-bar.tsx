"use client"

import { Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useLanguage } from "@/components/language-provider"

interface FixedTopBarProps {
  onNavigate: (section: string) => void
}

export function FixedTopBar({ onNavigate }: FixedTopBarProps) {
  const { t } = useLanguage()

  return (
    <div className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-r from-blue-600 to-purple-600 px-4 py-2 pt-12">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <h1 className="text-xl font-bold text-white">{t("app.name")}</h1>
          <Sparkles className="w-5 h-5 text-yellow-300 animate-pulse" />
        </div>
        <Button
          onClick={() => onNavigate("ai-assistant")}
          className="bg-white/20 hover:bg-white/30 text-white border border-white/30 rounded-full px-4 py-2 text-sm font-medium backdrop-blur-sm"
        >
          <Sparkles className="w-4 h-4 mr-1" />
          AI
        </Button>
      </div>
    </div>
  )
}
