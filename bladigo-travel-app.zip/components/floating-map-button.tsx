"use client"

import { useState } from "react"
import { MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { GoogleMapsIntegration } from "@/components/google-maps-integration"

export function FloatingMapButton() {
  const [showMap, setShowMap] = useState(false)

  return (
    <>
      <div className="fixed bottom-32 left-6 z-30">
        <Button
          onClick={() => setShowMap(true)}
          className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white rounded-full p-4 shadow-2xl animate-pulse hover:animate-none transition-all duration-300"
        >
          <MapPin className="w-6 h-6" />
        </Button>
      </div>

      {showMap && <GoogleMapsIntegration onClose={() => setShowMap(false)} />}
    </>
  )
}
