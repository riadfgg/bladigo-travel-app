"use client"

import { useState } from "react"
import { ArrowLeft, Calendar, Users, Bed, CreditCard, Check, MapPin, Star, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface Hotel {
  id: number
  name: string
  location: string
  rating: number
  price: string
  image: string
  amenities: string[]
}

interface HotelBookingProps {
  hotel: Hotel
  onBack: () => void
  onBookingComplete: (bookingData: any) => void
}

export function HotelBooking({ hotel, onBack, onBookingComplete }: HotelBookingProps) {
  const [step, setStep] = useState(1)
  const [bookingData, setBookingData] = useState({
    checkIn: "",
    checkOut: "",
    nights: 1,
    guests: 1,
    rooms: 1,
    roomType: "standard",
    specialRequests: "",
    guestName: "",
    guestPhone: "",
    guestEmail: "",
    paymentMethod: "card",
  })
  const [isProcessing, setIsProcessing] = useState(false)

  const calculateNights = (checkIn: string, checkOut: string) => {
    if (checkIn && checkOut) {
      const start = new Date(checkIn)
      const end = new Date(checkOut)
      const diffTime = Math.abs(end.getTime() - start.getTime())
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
      return diffDays
    }
    return 1
  }

  const handleDateChange = (field: string, value: string) => {
    const newData = { ...bookingData, [field]: value }
    if (field === "checkIn" || field === "checkOut") {
      newData.nights = calculateNights(newData.checkIn, newData.checkOut)
    }
    setBookingData(newData)
  }

  const getTotalPrice = () => {
    const basePrice = Number.parseInt(hotel.price.replace(/,/g, ""))
    return basePrice * bookingData.nights * bookingData.rooms
  }

  const handleBookingSubmit = async () => {
    setIsProcessing(true)

    // Simulate booking process
    await new Promise((resolve) => setTimeout(resolve, 3000))

    const booking = {
      ...bookingData,
      hotel: hotel,
      totalPrice: getTotalPrice(),
      bookingId: "BG" + Date.now(),
      status: "confirmed",
      bookingDate: new Date().toISOString(),
    }

    onBookingComplete(booking)
    setIsProcessing(false)
  }

  const roomTypes = [
    { id: "standard", name: "غرفة عادية", price: 0, description: "غرفة مريحة مع جميع المرافق الأساسية" },
    { id: "deluxe", name: "غرفة ديلوكس", price: 3000, description: "غرفة أكبر مع إطلالة جميلة" },
    { id: "suite", name: "جناح", price: 6000, description: "جناح فاخر مع صالة منفصلة" },
  ]

  if (step === 1) {
    return (
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <Button
            onClick={onBack}
            className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
          >
            <ArrowLeft className="w-6 h-6 text-gray-700 dark:text-gray-200" />
          </Button>
          <h1 className="text-xl font-bold text-gray-800 dark:text-white">حجز الفندق</h1>
          <div className="w-12"></div>
        </div>

        {/* Hotel Info */}
        <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl overflow-hidden">
          <div className="relative">
            <img src={hotel.image || "/placeholder.svg"} alt={hotel.name} className="w-full h-32 object-cover" />
            <div className="absolute top-4 left-4 bg-black/50 backdrop-blur-sm rounded-full px-3 py-1">
              <div className="flex items-center space-x-1">
                <Star className="w-4 h-4 text-yellow-400 fill-current" />
                <span className="text-white text-sm font-medium">{hotel.rating}</span>
              </div>
            </div>
          </div>
          <div className="p-4">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white">{hotel.name}</h3>
            <div className="flex items-center space-x-2 text-gray-600 dark:text-gray-300">
              <MapPin className="w-4 h-4" />
              <span className="text-sm">{hotel.location}</span>
            </div>
          </div>
        </Card>

        {/* Booking Form */}
        <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
          <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">تفاصيل الحجز</h3>

          <div className="space-y-4">
            {/* Dates */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">تاريخ الوصول</label>
                <div className="relative">
                  <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="date"
                    value={bookingData.checkIn}
                    onChange={(e) => handleDateChange("checkIn", e.target.value)}
                    className="w-full bg-white/10 border border-white/20 rounded-xl px-12 py-3 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  تاريخ المغادرة
                </label>
                <div className="relative">
                  <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="date"
                    value={bookingData.checkOut}
                    onChange={(e) => handleDateChange("checkOut", e.target.value)}
                    className="w-full bg-white/10 border border-white/20 rounded-xl px-12 py-3 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
              </div>
            </div>

            {/* Nights Display */}
            {bookingData.checkIn && bookingData.checkOut && (
              <div className="bg-blue-500/20 rounded-xl p-3">
                <div className="flex items-center space-x-2">
                  <Clock className="w-5 h-5 text-blue-600" />
                  <span className="text-blue-800 dark:text-blue-200 font-medium">
                    عدد الليالي: {bookingData.nights} ليلة
                  </span>
                </div>
              </div>
            )}

            {/* Guests and Rooms */}
            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">الضيوف</label>
                <div className="relative">
                  <Users className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <select
                    value={bookingData.guests}
                    onChange={(e) => setBookingData({ ...bookingData, guests: Number.parseInt(e.target.value) })}
                    className="w-full bg-white/10 border border-white/20 rounded-xl px-12 py-3 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {[1, 2, 3, 4, 5, 6].map((num) => (
                      <option key={num} value={num}>
                        {num}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">الغرف</label>
                <div className="relative">
                  <Bed className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <select
                    value={bookingData.rooms}
                    onChange={(e) => setBookingData({ ...bookingData, rooms: Number.parseInt(e.target.value) })}
                    className="w-full bg-white/10 border border-white/20 rounded-xl px-12 py-3 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {[1, 2, 3, 4].map((num) => (
                      <option key={num} value={num}>
                        {num}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Room Type */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">نوع الغرفة</label>
              <div className="space-y-3">
                {roomTypes.map((room) => (
                  <div
                    key={room.id}
                    className={`p-4 rounded-xl border-2 cursor-pointer transition-all duration-300 ${
                      bookingData.roomType === room.id
                        ? "border-blue-500 bg-blue-500/20"
                        : "border-white/20 bg-white/10 hover:bg-white/20"
                    }`}
                    onClick={() => setBookingData({ ...bookingData, roomType: room.id })}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium text-gray-800 dark:text-white">{room.name}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-300">{room.description}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-blue-600">+{room.price.toLocaleString()} دج</p>
                        <p className="text-xs text-gray-500">لكل ليلة</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Special Requests */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                طلبات خاصة (اختياري)
              </label>
              <textarea
                value={bookingData.specialRequests}
                onChange={(e) => setBookingData({ ...bookingData, specialRequests: e.target.value })}
                placeholder="أي طلبات خاصة أو ملاحظات..."
                className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-gray-800 dark:text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                rows={3}
              />
            </div>
          </div>
        </Card>

        {/* Price Summary */}
        {bookingData.checkIn && bookingData.checkOut && (
          <Card className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 backdrop-blur-md border border-white/30 rounded-2xl p-6">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">ملخص التكلفة</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-300">
                  {hotel.price} دج × {bookingData.nights} ليلة × {bookingData.rooms} غرفة
                </span>
                <span className="font-medium text-gray-800 dark:text-white">
                  {(
                    Number.parseInt(hotel.price.replace(/,/g, "")) *
                    bookingData.nights *
                    bookingData.rooms
                  ).toLocaleString()}{" "}
                  دج
                </span>
              </div>
              {bookingData.roomType !== "standard" && (
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-300">
                    رسوم نوع الغرفة ({roomTypes.find((r) => r.id === bookingData.roomType)?.name})
                  </span>
                  <span className="font-medium text-gray-800 dark:text-white">
                    +
                    {(roomTypes.find((r) => r.id === bookingData.roomType)?.price || 0) *
                      bookingData.nights *
                      bookingData.rooms}{" "}
                    دج
                  </span>
                </div>
              )}
              <div className="border-t border-white/20 pt-2">
                <div className="flex justify-between">
                  <span className="text-lg font-bold text-gray-800 dark:text-white">المجموع</span>
                  <span className="text-xl font-bold text-green-600">{getTotalPrice().toLocaleString()} دج</span>
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* Continue Button */}
        <Button
          onClick={() => setStep(2)}
          disabled={!bookingData.checkIn || !bookingData.checkOut}
          className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 disabled:opacity-50 text-white py-4 rounded-2xl font-bold text-lg"
        >
          متابعة إلى بيانات الضيف
        </Button>
      </div>
    )
  }

  if (step === 2) {
    return (
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <Button
            onClick={() => setStep(1)}
            className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
          >
            <ArrowLeft className="w-6 h-6 text-gray-700 dark:text-gray-200" />
          </Button>
          <h1 className="text-xl font-bold text-gray-800 dark:text-white">بيانات الضيف</h1>
          <div className="w-12"></div>
        </div>

        {/* Guest Information */}
        <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
          <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">معلومات الضيف الرئيسي</h3>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">الاسم الكامل *</label>
              <input
                type="text"
                value={bookingData.guestName}
                onChange={(e) => setBookingData({ ...bookingData, guestName: e.target.value })}
                className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">رقم الهاتف *</label>
              <input
                type="tel"
                value={bookingData.guestPhone}
                onChange={(e) => setBookingData({ ...bookingData, guestPhone: e.target.value })}
                className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                البريد الإلكتروني *
              </label>
              <input
                type="email"
                value={bookingData.guestEmail}
                onChange={(e) => setBookingData({ ...bookingData, guestEmail: e.target.value })}
                className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>
          </div>
        </Card>

        {/* Payment Method */}
        <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
          <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">طريقة الدفع</h3>

          <div className="space-y-3">
            <div
              className={`p-4 rounded-xl border-2 cursor-pointer transition-all duration-300 ${
                bookingData.paymentMethod === "card"
                  ? "border-blue-500 bg-blue-500/20"
                  : "border-white/20 bg-white/10 hover:bg-white/20"
              }`}
              onClick={() => setBookingData({ ...bookingData, paymentMethod: "card" })}
            >
              <div className="flex items-center space-x-3">
                <CreditCard className="w-6 h-6 text-blue-600" />
                <div>
                  <h4 className="font-medium text-gray-800 dark:text-white">بطاقة ائتمان</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">دفع آمن بالبطاقة الائتمانية</p>
                </div>
              </div>
            </div>

            <div
              className={`p-4 rounded-xl border-2 cursor-pointer transition-all duration-300 ${
                bookingData.paymentMethod === "cash"
                  ? "border-blue-500 bg-blue-500/20"
                  : "border-white/20 bg-white/10 hover:bg-white/20"
              }`}
              onClick={() => setBookingData({ ...bookingData, paymentMethod: "cash" })}
            >
              <div className="flex items-center space-x-3">
                <span className="text-2xl">💰</span>
                <div>
                  <h4 className="font-medium text-gray-800 dark:text-white">الدفع في الفندق</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">ادفع عند الوصول للفندق</p>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Booking Summary */}
        <Card className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 backdrop-blur-md border border-white/30 rounded-2xl p-6">
          <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">ملخص الحجز</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-300">الفندق:</span>
              <span className="font-medium text-gray-800 dark:text-white">{hotel.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-300">التواريخ:</span>
              <span className="font-medium text-gray-800 dark:text-white">
                {bookingData.checkIn} إلى {bookingData.checkOut}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-300">عدد الليالي:</span>
              <span className="font-medium text-gray-800 dark:text-white">{bookingData.nights}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-300">الضيوف:</span>
              <span className="font-medium text-gray-800 dark:text-white">{bookingData.guests}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600 dark:text-gray-300">الغرف:</span>
              <span className="font-medium text-gray-800 dark:text-white">{bookingData.rooms}</span>
            </div>
            <div className="border-t border-white/20 pt-2">
              <div className="flex justify-between">
                <span className="text-lg font-bold text-gray-800 dark:text-white">المجموع:</span>
                <span className="text-xl font-bold text-purple-600">{getTotalPrice().toLocaleString()} دج</span>
              </div>
            </div>
          </div>
        </Card>

        {/* Confirm Booking Button */}
        <Button
          onClick={handleBookingSubmit}
          disabled={!bookingData.guestName || !bookingData.guestPhone || !bookingData.guestEmail || isProcessing}
          className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 disabled:opacity-50 text-white py-4 rounded-2xl font-bold text-lg"
        >
          {isProcessing ? (
            <div className="flex items-center justify-center space-x-2">
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              <span>جاري تأكيد الحجز...</span>
            </div>
          ) : (
            <div className="flex items-center justify-center space-x-2">
              <Check className="w-5 h-5" />
              <span>تأكيد الحجز</span>
            </div>
          )}
        </Button>
      </div>
    )
  }

  return null
}
