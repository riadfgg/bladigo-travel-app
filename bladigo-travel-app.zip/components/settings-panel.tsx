"use client"

import { useState } from "react"
import { ArrowLeft, Globe, Moon, Sun, Bell, Shield, HelpCircle, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { useTheme } from "@/components/theme-provider"

interface SettingsPanelProps {
  onBack: () => void
}

export function SettingsPanel({ onBack }: SettingsPanelProps) {
  const { theme, toggleTheme } = useTheme()
  const [notifications, setNotifications] = useState(true)
  const [language, setLanguage] = useState("English")
  const [culturalFirst, setCulturalFirst] = useState(true)

  const languages = [
    { code: "ar", name: "العربية", flag: "🇩🇿" },
    { code: "en", name: "English", flag: "🇺🇸" },
    { code: "fr", name: "Français", flag: "🇫🇷" },
    { code: "es", name: "Español", flag: "🇪🇸" },
    { code: "zh", name: "中文", flag: "🇨🇳" },
    { code: "ru", name: "Русский", flag: "🇷🇺" },
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <Button
          onClick={onBack}
          className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
        >
          <ArrowLeft className="w-6 h-6 text-gray-700 dark:text-gray-200" />
        </Button>
        <h1 className="text-2xl font-bold text-gray-800 dark:text-white">Settings</h1>
        <div className="w-12"></div>
      </div>

      {/* Language Settings */}
      <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
        <div className="flex items-center space-x-3 mb-4">
          <Globe className="w-6 h-6 text-blue-600" />
          <h3 className="text-lg font-bold text-gray-800 dark:text-white">Language</h3>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {languages.map((lang) => (
            <Button
              key={lang.code}
              onClick={() => setLanguage(lang.name)}
              className={`p-3 rounded-xl transition-all duration-300 ${
                language === lang.name
                  ? "bg-gradient-to-r from-blue-500 to-cyan-500 text-white"
                  : "bg-white/20 dark:bg-white/10 hover:bg-white/30 text-gray-700 dark:text-gray-200"
              }`}
            >
              <div className="flex items-center space-x-2">
                <span>{lang.flag}</span>
                <span className="text-sm">{lang.name}</span>
              </div>
            </Button>
          ))}
        </div>
      </Card>

      {/* Theme Settings */}
      <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            {theme === "dark" ? (
              <Moon className="w-6 h-6 text-purple-600" />
            ) : (
              <Sun className="w-6 h-6 text-amber-600" />
            )}
            <div>
              <h3 className="text-lg font-bold text-gray-800 dark:text-white">Theme</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                {theme === "dark" ? "Dark mode enabled" : "Light mode enabled"}
              </p>
            </div>
          </div>
          <Button
            onClick={toggleTheme}
            className={`relative w-16 h-8 rounded-full transition-all duration-300 ${
              theme === "dark" ? "bg-purple-500" : "bg-amber-400"
            }`}
          >
            <div
              className={`absolute w-6 h-6 bg-white rounded-full transition-all duration-300 transform ${
                theme === "dark" ? "translate-x-8" : "translate-x-1"
              } top-1`}
            />
          </Button>
        </div>
      </Card>

      {/* Notifications */}
      <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Bell className="w-6 h-6 text-emerald-600" />
            <div>
              <h3 className="text-lg font-bold text-gray-800 dark:text-white">Notifications</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300">Location-based travel alerts</p>
            </div>
          </div>
          <Button
            onClick={() => setNotifications(!notifications)}
            className={`relative w-16 h-8 rounded-full transition-all duration-300 ${
              notifications ? "bg-emerald-500" : "bg-gray-300"
            }`}
          >
            <div
              className={`absolute w-6 h-6 bg-white rounded-full transition-all duration-300 transform ${
                notifications ? "translate-x-8" : "translate-x-1"
              } top-1`}
            />
          </Button>
        </div>
      </Card>

      {/* Preferences */}
      <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <MapPin className="w-6 h-6 text-amber-600" />
            <div>
              <h3 className="text-lg font-bold text-gray-800 dark:text-white">Cultural Places First</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300">Prioritize cultural attractions</p>
            </div>
          </div>
          <Button
            onClick={() => setCulturalFirst(!culturalFirst)}
            className={`relative w-16 h-8 rounded-full transition-all duration-300 ${
              culturalFirst ? "bg-amber-500" : "bg-gray-300"
            }`}
          >
            <div
              className={`absolute w-6 h-6 bg-white rounded-full transition-all duration-300 transform ${
                culturalFirst ? "translate-x-8" : "translate-x-1"
              } top-1`}
            />
          </Button>
        </div>
      </Card>

      {/* Other Settings */}
      <div className="space-y-3">
        <Button className="w-full bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 rounded-2xl p-4 justify-start">
          <Shield className="w-6 h-6 text-red-600 mr-3" />
          <span className="text-gray-800 dark:text-white">Privacy & Security</span>
        </Button>

        <Button className="w-full bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 rounded-2xl p-4 justify-start">
          <HelpCircle className="w-6 h-6 text-blue-600 mr-3" />
          <span className="text-gray-800 dark:text-white">Help & Support</span>
        </Button>
      </div>
    </div>
  )
}
