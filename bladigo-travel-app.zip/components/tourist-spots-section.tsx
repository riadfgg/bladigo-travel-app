"use client"

import { useState } from "react"
import { ArrowLeft, Star, Navigation, Clock, Camera, MapPin, Play, Heart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

// Import language support and Google Maps
import { useLanguage } from "@/components/language-provider"
import { useLocation } from "@/components/location-provider"

interface TouristSpot {
  id: number
  name: string
  location: string
  rating: number
  distance: string
  image: string
  description: string
  estimatedTime: string
  category: string
  beautyRating: number
  accessibilityRating: number
  cleanlinessRating: number
  hasVideo: boolean
  aiSuggestions: string[]
  coordinates: { lat: number; lng: number }
}

interface TouristSpotsSectionProps {
  onBack: () => void
}

export function TouristSpotsSection({ onBack }: TouristSpotsSectionProps) {
  const [selectedSpot, setSelectedSpot] = useState<number | null>(null)
  const [favorites, setFavorites] = useState<number[]>([])

  // Add state for Google Maps
  const { location } = useLocation()
  const { t, isRTL } = useLanguage()

  // Update tourist spots with real images and coordinates
  const touristSpots: TouristSpot[] = [
    {
      id: 1,
      name: "Makam El Chahid",
      location: "Algiers",
      rating: 4.8,
      distance: "2.3 km",
      image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=300&fit=crop",
      description:
        "Iconic monument commemorating martyrs of the Algerian War. A symbol of independence and national pride.",
      estimatedTime: "1-2 hours",
      category: "Monument",
      beautyRating: 4.9,
      accessibilityRating: 4.5,
      cleanlinessRating: 4.7,
      hasVideo: true,
      aiSuggestions: ["Casbah of Algiers", "Notre Dame d'Afrique", "Botanical Garden"],
      coordinates: { lat: 36.7538, lng: 3.0588 },
    },
    {
      id: 2,
      name: "Timgad Ruins",
      location: "Batna",
      rating: 4.9,
      distance: "15.7 km",
      image: "https://images.unsplash.com/photo-1539650116574-75c0c6d73f6e?w=400&h=300&fit=crop",
      description: "UNESCO World Heritage Roman archaeological site with remarkably preserved ancient architecture.",
      estimatedTime: "3-4 hours",
      category: "Historical",
      beautyRating: 4.8,
      accessibilityRating: 4.2,
      cleanlinessRating: 4.6,
      hasVideo: true,
      aiSuggestions: ["Djemila", "Hippo Regius", "Guelma Hot Springs"],
      coordinates: { lat: 35.4833, lng: 6.4667 },
    },
    {
      id: 3,
      name: "Fort Santa Cruz",
      location: "Oran",
      rating: 4.7,
      distance: "8.2 km",
      image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=300&fit=crop",
      description: "Historic fortress offering breathtaking sunset views over the Mediterranean Sea.",
      estimatedTime: "2-3 hours",
      category: "Historical",
      beautyRating: 4.9,
      accessibilityRating: 4.0,
      cleanlinessRating: 4.5,
      hasVideo: true,
      aiSuggestions: ["Great Mosque of Oran", "Le Théâtre", "Ain El Turck Beach"],
      coordinates: { lat: 35.7089, lng: -0.6178 },
    },
    {
      id: 4,
      name: "Casbah of Algiers",
      location: "Algiers",
      rating: 4.6,
      distance: "1.8 km",
      image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=300&fit=crop",
      description: "Historic medina and UNESCO World Heritage site with traditional Ottoman architecture.",
      estimatedTime: "4-5 hours",
      category: "Cultural",
      beautyRating: 4.7,
      accessibilityRating: 3.8,
      cleanlinessRating: 4.3,
      hasVideo: true,
      aiSuggestions: ["Ketchaoua Mosque", "Palace of the Dey", "Bardo Museum"],
      coordinates: { lat: 36.7833, lng: 3.0667 },
    },
    {
      id: 5,
      name: "Sahara Desert - Taghit",
      location: "Bechar",
      rating: 4.9,
      distance: "450 km",
      image: "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=400&h=300&fit=crop",
      description: "Breathtaking sand dunes and oasis town in the heart of the Sahara Desert.",
      estimatedTime: "Full day",
      category: "Nature",
      beautyRating: 5.0,
      accessibilityRating: 3.5,
      cleanlinessRating: 4.8,
      hasVideo: true,
      aiSuggestions: ["Timimoun Oasis", "Ghardaia", "Hoggar Mountains"],
      coordinates: { lat: 31.0167, lng: -2.0333 },
    },
    {
      id: 6,
      name: "Djemila Archaeological Site",
      location: "Setif",
      rating: 4.8,
      distance: "25 km",
      image: "https://images.unsplash.com/photo-1539650116574-75c0c6d73f6e?w=400&h=300&fit=crop",
      description: "UNESCO World Heritage Roman ruins with spectacular mountain backdrop.",
      estimatedTime: "3-4 hours",
      category: "Historical",
      beautyRating: 4.8,
      accessibilityRating: 4.1,
      cleanlinessRating: 4.6,
      hasVideo: true,
      aiSuggestions: ["Timgad", "Constantine Bridges", "Tiddis Ruins"],
      coordinates: { lat: 36.3167, lng: 5.7333 },
    },
  ]

  const toggleFavorite = (spotId: number) => {
    setFavorites((prev) => (prev.includes(spotId) ? prev.filter((id) => id !== spotId) : [...prev, spotId]))
  }

  if (selectedSpot) {
    const spot = touristSpots.find((s) => s.id === selectedSpot)!
    return (
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <Button
            onClick={() => setSelectedSpot(null)}
            className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
          >
            <ArrowLeft className="w-6 h-6 text-gray-700 dark:text-gray-200" />
          </Button>
          <h1 className="text-xl font-bold text-gray-800 dark:text-white">Destination Details</h1>
          <Button
            onClick={() => toggleFavorite(spot.id)}
            className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
          >
            <Heart
              className={`w-6 h-6 ${favorites.includes(spot.id) ? "text-red-500 fill-current" : "text-gray-700 dark:text-gray-200"}`}
            />
          </Button>
        </div>

        {/* Image & Video */}
        <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl overflow-hidden">
          <div className="relative">
            <img src={spot.image || "/placeholder.svg"} alt={spot.name} className="w-full h-64 object-cover" />
            {spot.hasVideo && (
              <Button className="absolute inset-0 bg-black/30 hover:bg-black/50 transition-all duration-300 flex items-center justify-center">
                <Play className="w-16 h-16 text-white fill-current" />
              </Button>
            )}
            <div className="absolute top-4 left-4 bg-emerald-500/80 backdrop-blur-sm rounded-full px-3 py-1">
              <span className="text-white text-sm font-medium">{spot.category}</span>
            </div>
          </div>
        </Card>

        {/* Details */}
        <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">{spot.name}</h2>
              <div className="flex items-center space-x-2 text-gray-600 dark:text-gray-300 mb-2">
                <MapPin className="w-4 h-4" />
                <span>{spot.location}</span>
              </div>
              <div className="flex items-center space-x-2 text-blue-600">
                <Navigation className="w-4 h-4" />
                <span className="text-sm font-medium">{spot.distance}</span>
              </div>
            </div>
            <div className="text-right">
              <div className="flex items-center space-x-1 mb-2">
                <Star className="w-5 h-5 text-yellow-400 fill-current" />
                <span className="text-xl font-bold text-gray-800 dark:text-white">{spot.rating}</span>
              </div>
              <div className="flex items-center space-x-1 text-emerald-600">
                <Clock className="w-4 h-4" />
                <span className="text-sm">{spot.estimatedTime}</span>
              </div>
            </div>
          </div>

          <p className="text-gray-600 dark:text-gray-300 mb-6">{spot.description}</p>

          {/* Ratings */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="text-center">
              <div className="text-lg font-bold text-pink-600">{spot.beautyRating}</div>
              <div className="text-xs text-gray-500">Beauty</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold text-blue-600">{spot.accessibilityRating}</div>
              <div className="text-xs text-gray-500">Access</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold text-green-600">{spot.cleanlinessRating}</div>
              <div className="text-xs text-gray-500">Clean</div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-3">
            <Button className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white rounded-xl">
              <Navigation className="w-4 h-4 mr-2" />
              Get Directions
            </Button>
            <Button className="bg-white/20 dark:bg-white/10 hover:bg-white/30 text-gray-700 dark:text-gray-200 rounded-xl">
              <Camera className="w-4 h-4 mr-2" />
              Gallery
            </Button>
          </div>
        </Card>

        {/* AI Suggestions */}
        <Card className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl p-6">
          <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">🤖 You may also like...</h3>
          <div className="space-y-2">
            {spot.aiSuggestions.map((suggestion, index) => (
              <div key={index} className="bg-white/10 rounded-xl p-3">
                <span className="text-gray-700 dark:text-gray-200">{suggestion}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    )
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <Button
          onClick={onBack}
          className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
        >
          <ArrowLeft className="w-6 h-6 text-gray-700 dark:text-gray-200" />
        </Button>
        <h1 className="text-2xl font-bold text-gray-800 dark:text-white">Tourist Destinations</h1>
        <div className="w-12"></div>
      </div>

      {/* Spots Grid */}
      <div className="space-y-4">
        {touristSpots.map((spot) => (
          <Card
            key={spot.id}
            className="bg-white/20 dark:bg-white/10 backdrop-blur-md border border-white/30 rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 cursor-pointer"
            onClick={() => setSelectedSpot(spot.id)}
          >
            <div className="relative">
              <img src={spot.image || "/placeholder.svg"} alt={spot.name} className="w-full h-48 object-cover" />
              <div className="absolute top-4 right-4 bg-black/50 backdrop-blur-sm rounded-full px-3 py-1">
                <div className="flex items-center space-x-1">
                  <Star className="w-4 h-4 text-yellow-400 fill-current" />
                  <span className="text-white text-sm font-medium">{spot.rating}</span>
                </div>
              </div>
              <div className="absolute top-4 left-4 bg-emerald-500/80 backdrop-blur-sm rounded-full px-3 py-1">
                <span className="text-white text-xs font-medium">{spot.category}</span>
              </div>
              {spot.hasVideo && (
                <div className="absolute bottom-4 right-4 bg-red-500/80 backdrop-blur-sm rounded-full p-2">
                  <Play className="w-4 h-4 text-white fill-current" />
                </div>
              )}
            </div>

            <div className="p-4">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h3 className="text-lg font-bold text-gray-800 dark:text-white">{spot.name}</h3>
                  <p className="text-gray-600 dark:text-gray-300">{spot.location}</p>
                </div>
                <div className="flex items-center space-x-1 text-blue-600">
                  <Navigation className="w-4 h-4" />
                  <span className="text-sm font-medium">{spot.distance}</span>
                </div>
              </div>

              <p className="text-gray-600 dark:text-gray-300 text-sm mb-3 line-clamp-2">{spot.description}</p>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-1 text-emerald-600">
                  <Clock className="w-4 h-4" />
                  <span className="text-sm">{spot.estimatedTime}</span>
                </div>
                <Button
                  onClick={(e) => {
                    e.stopPropagation()
                    toggleFavorite(spot.id)
                  }}
                  className="bg-white/20 hover:bg-white/30 rounded-full p-2"
                >
                  <Heart
                    className={`w-4 h-4 ${favorites.includes(spot.id) ? "text-red-500 fill-current" : "text-gray-500"}`}
                  />
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
