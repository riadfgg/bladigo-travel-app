"use client"

import { useState } from "react"
import { ArrowLeft, Play, Heart, Share, MessageCircle, Volume2, VolumeX } from "lucide-react"
import { Button } from "@/components/ui/button"

interface VideoReelsProps {
  onNavigate: (screen: string) => void
}

const reels = [
  {
    id: 1,
    title: "Sunset at Fort Santa Cruz",
    location: "Oran, Algeria",
    thumbnail: "/placeholder.svg?height=600&width=400",
    likes: 1247,
    comments: 89,
    description: "Breathtaking sunset views from the historic fortress",
  },
  {
    id: 2,
    title: "Exploring Timgad Ruins",
    location: "Batna, Algeria",
    thumbnail: "/placeholder.svg?height=600&width=400",
    likes: 892,
    comments: 56,
    description: "Walking through 2000-year-old Roman history",
  },
  {
    id: 3,
    title: "Casbah Morning Walk",
    location: "Algiers, Algeria",
    thumbnail: "/placeholder.svg?height=600&width=400",
    likes: 1456,
    comments: 123,
    description: "Traditional architecture and vibrant street life",
  },
  {
    id: 4,
    title: "Sahara Desert Adventure",
    location: "Tamanrasset, Algeria",
    thumbnail: "/placeholder.svg?height=600&width=400",
    likes: 2103,
    comments: 187,
    description: "Epic journey through golden sand dunes",
  },
]

export function VideoReels({ onNavigate }: VideoReelsProps) {
  const [currentReel, setCurrentReel] = useState(0)
  const [liked, setLiked] = useState<number[]>([])
  const [muted, setMuted] = useState(true)

  const toggleLike = (reelId: number) => {
    setLiked((prev) => (prev.includes(reelId) ? prev.filter((id) => id !== reelId) : [...prev, reelId]))
  }

  return (
    <div className="min-h-screen relative overflow-hidden bg-black">
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between p-6 pt-12 bg-gradient-to-b from-black/50 to-transparent">
        <Button
          onClick={() => onNavigate("home")}
          className="bg-white/20 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
        >
          <ArrowLeft className="w-6 h-6 text-white" />
        </Button>
        <h1 className="text-xl font-bold text-white">Discover Algeria</h1>
        <Button
          onClick={() => setMuted(!muted)}
          className="bg-white/20 backdrop-blur-md border border-white/30 hover:bg-white/30 transition-all duration-300 rounded-full p-3"
        >
          {muted ? <VolumeX className="w-6 h-6 text-white" /> : <Volume2 className="w-6 h-6 text-white" />}
        </Button>
      </div>

      {/* Video Reel */}
      <div className="relative h-screen">
        <img
          src={reels[currentReel].thumbnail || "/placeholder.svg"}
          alt={reels[currentReel].title}
          className="w-full h-full object-cover"
        />

        {/* Play Button Overlay */}
        <div className="absolute inset-0 flex items-center justify-center">
          <Button className="bg-black/50 backdrop-blur-sm hover:bg-black/70 rounded-full p-6 transition-all duration-300 transform hover:scale-110">
            <Play className="w-12 h-12 text-white fill-current" />
          </Button>
        </div>

        {/* Bottom Gradient */}
        <div className="absolute bottom-0 left-0 right-0 h-1/3 bg-gradient-to-t from-black/80 to-transparent"></div>
      </div>

      {/* Content Overlay */}
      <div className="absolute bottom-0 left-0 right-0 p-6 pb-32">
        <div className="flex justify-between items-end">
          {/* Video Info */}
          <div className="flex-1 mr-4">
            <h2 className="text-2xl font-bold text-white mb-2">{reels[currentReel].title}</h2>
            <p className="text-white/80 mb-2">{reels[currentReel].location}</p>
            <p className="text-white/70 text-sm">{reels[currentReel].description}</p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col space-y-4">
            <Button
              onClick={() => toggleLike(reels[currentReel].id)}
              className="bg-white/20 backdrop-blur-md hover:bg-white/30 rounded-full p-4 transition-all duration-300"
            >
              <Heart
                className={`w-6 h-6 ${liked.includes(reels[currentReel].id) ? "text-red-500 fill-current" : "text-white"}`}
              />
            </Button>
            <div className="text-center">
              <p className="text-white text-sm font-medium">{reels[currentReel].likes}</p>
            </div>

            <Button className="bg-white/20 backdrop-blur-md hover:bg-white/30 rounded-full p-4 transition-all duration-300">
              <MessageCircle className="w-6 h-6 text-white" />
            </Button>
            <div className="text-center">
              <p className="text-white text-sm font-medium">{reels[currentReel].comments}</p>
            </div>

            <Button className="bg-white/20 backdrop-blur-md hover:bg-white/30 rounded-full p-4 transition-all duration-300">
              <Share className="w-6 h-6 text-white" />
            </Button>
          </div>
        </div>
      </div>

      {/* Navigation Dots */}
      <div className="absolute bottom-20 left-1/2 transform -translate-x-1/2 flex space-x-2">
        {reels.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentReel(index)}
            className={`w-2 h-2 rounded-full transition-all duration-300 ${
              index === currentReel ? "bg-white" : "bg-white/50"
            }`}
          />
        ))}
      </div>

      {/* Swipe Indicators */}
      <div className="absolute left-4 top-1/2 transform -translate-y-1/2">
        <div className="flex flex-col space-y-2">
          {currentReel > 0 && (
            <Button
              onClick={() => setCurrentReel(currentReel - 1)}
              className="bg-white/20 backdrop-blur-md hover:bg-white/30 rounded-full p-2"
            >
              <div className="w-4 h-4 border-t-2 border-l-2 border-white transform rotate-45"></div>
            </Button>
          )}
        </div>
      </div>

      <div className="absolute right-4 top-1/2 transform -translate-y-1/2">
        <div className="flex flex-col space-y-2">
          {currentReel < reels.length - 1 && (
            <Button
              onClick={() => setCurrentReel(currentReel + 1)}
              className="bg-white/20 backdrop-blur-md hover:bg-white/30 rounded-full p-2"
            >
              <div className="w-4 h-4 border-t-2 border-r-2 border-white transform -rotate-45"></div>
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}
